# PANEL (app Android + Backend API)

```
├── android-app/    App Android cho người dùng (Kotlin). Không chứa Admin, không chứa secret.
└── backend-api/    Node.js + Express + PostgreSQL (KEY, phiên, thiết bị, Panel API, API quản trị có xác thực)
```
Website quản trị là gói riêng: `admin-dashboard.zip`.
- Backend: xem `backend-api/README.md` (đặt `ADMIN_ORIGINS` = địa chỉ website Admin).
- Android: xem `android-app/README.md` (`SERVER_URL` = địa chỉ Backend).
