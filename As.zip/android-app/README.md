# Android App (Kotlin, package `com.fpm.panel`)

Ứng dụng người dùng: màn nhập KEY, Trang chủ (trạng thái KEY/thời hạn/máy chủ), Floating Panel (kéo thả, thu nhỏ, chức năng/nhạc/liên hệ do Admin cấu hình từ xa), Cài đặt. Không có màn hình, link hay API quản trị.

## Build
1. Android Studio (Koala+, JDK 17) → *Open* thư mục `android-app/` → chờ Gradle sync (cần Internet).
2. Sửa `gradle.properties`: `SERVER_URL=https://api.your-domain.com` (địa chỉ **Backend API**, HTTPS, không có `/` cuối). Hiện đang là `https://huunhanpanel.duckdns.org`.
3. Debug: nối điện thoại → ▶ Run, hoặc `./gradlew assembleDebug`.
4. Release: *Build → Generate Signed App Bundle / APK* (tạo keystore, **giữ file + mật khẩu**), hoặc cấu hình `signingConfig` rồi `./gradlew assembleRelease`.
Thử với máy ảo + server trên PC: `SERVER_URL=http://10.0.2.2:3000` và tạm đặt `usesCleartextTraffic="true"` (trả về `false` khi phát hành).

## Bảo mật
- APK chỉ chứa `SERVER_URL`; chỉ gọi `/api/v1/config`, `/keys/activate`, `/keys/status`, `/panel`, `/panel/features/:id/toggle|run`.
- Session lưu bằng EncryptedSharedPreferences (Android Keystore). Thời hạn KEY luôn do Server quyết định.
- Không có secret, tài khoản hay đường dẫn quản trị trong source (đã quét `api/admin`, `ADMIN_JWT`, `SESSION_SECRET`, `KEY_PEPPER`, `password`: không có).
- Nội dung quản trị viên chỉ xuất hiện dưới dạng thông tin hỗ trợ (tên, liên kết liên hệ) do Admin chọn công khai.

## Thay logo
Logo/ảnh nền/banner đổi từ xa trong Dashboard. Logo đóng gói sẵn: thay `res/drawable/logo_default.*`, `logo_panel.*`, `ic_launcher.*`.
