package com.fpm.panel

import android.content.Context
import android.content.Intent
import android.provider.Settings

sealed class Sync { object Ok : Sync(); object Offline : Sync(); class Locked(val status: String, val msg: String) : Sync() }

object Session {
    fun deviceId(c: Context): String = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
    fun bootCount(c: Context): Int = try { Settings.Global.getInt(c.contentResolver, "boot_count", -1) } catch (e: Exception) { -1 }

    /** Hỏi Server về trạng thái KEY hiện tại và đồng bộ thời hạn. */
    suspend fun sync(c: Context): Sync {
        val st = Store.get(c)
        val s = st.session ?: return Sync.Locked("INVALID", "Chưa kích hoạt KEY")
        val r = Api.status(s, deviceId(c))
        if (r.net || r.code in 500..599 || r.code == 429) return Sync.Offline
        if (r.code == 200 && r.json.optBoolean("ok")) { st.saveState(r.json, bootCount(c)); return Sync.Ok }
        return Sync.Locked(r.json.optString("status", "INVALID"), r.json.optString("error", "Phiên không hợp lệ"))
    }

    /** Khóa quyền sử dụng: dừng panel, xóa phiên, quay về màn nhập KEY. */
    fun lockAndExit(c: Context, msg: String) {
        c.stopService(Intent(c, FloatingService::class.java))
        Store.get(c).clearSession()
        c.startActivity(Intent(c, KeyActivity::class.java).putExtra("msg", msg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    }
}
