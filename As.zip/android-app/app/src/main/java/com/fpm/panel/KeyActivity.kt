package com.fpm.panel

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import kotlinx.coroutines.*

class KeyActivity : Activity() {

    private val scope = MainScope()
    private lateinit var st: Store

    private var cfg = AppConfig.default()
    private var keyText = ""
    private var online: Boolean? = null
    private var msg = ""
    private var msgOk = false
    private var busy = false

    private val GREEN = 0xFF25F5B2.toInt()
    private val BLUE = 0xFF318BFF.toInt()
    private val PURPLE = 0xFF9666FF.toInt()
    private val WHITE = Color.WHITE
    private val GREY = 0xFF8995B2.toInt()
    private val RED = 0xFFFF5470.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        window.statusBarColor = 0xFF080D19.toInt()
        window.navigationBarColor = 0xFF080D19.toInt()

        st = Store.get(this)
        cfg = st.config()

        msg = intent.getStringExtra("msg") ?: ""

        build()

        if (st.session != null && msg.isEmpty()) {
            scope.launch {
                when (val s = Session.sync(this@KeyActivity)) {
                    is Sync.Ok -> goHome()

                    is Sync.Offline -> {
                        if (st.canUseOffline(this@KeyActivity)) {
                            goHome()
                        }
                    }

                    is Sync.Locked -> {
                        st.clearSession()
                        msg = if (s.status == "EXPIRED") {
                            cfg.expiredMessage
                        } else {
                            s.msg
                        }
                        build()
                    }
                }
            }
        }

        scope.launch {
            val c = Api.config()
            online = c != null

            if (c != null) {
                st.saveConfig(c)
                cfg = c
            }

            build()
        }
    }

    private fun goHome() {
        startActivity(
            Intent(this, HomeActivity::class.java)
        )
        finish()
    }

    private fun copyText(t: String) {
        val clipboard =
            getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        clipboard.setPrimaryClip(
            ClipData.newPlainText("key", t)
        )

        Toast.makeText(
            this,
            "Đã sao chép",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun gap(
        parent: LinearLayout,
        h: Int
    ) {
        parent.addView(
            View(this),
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                dp(h)
            )
        )
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL

            setPadding(
                dp(17),
                dp(17),
                dp(17),
                dp(17)
            )

            background = roundedBg(
                0xFF111A2D.toInt(),
                dp(19).toFloat(),
                0xFF34446A.toInt(),
                dp(1)
            )
        }
    }

    private fun build() {
        val c = cfg

        val root = FrameLayout(this).apply {
            background = gradientBg(
                0xFF080D19.toInt(),
                0xFF101A32.toInt()
            )
        }

        // BACKGROUND IMAGE
        val bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.20f
        }

        root.addView(
            bg,
            FrameLayout.LayoutParams(
                MATCH_PARENT,
                MATCH_PARENT
            )
        )

        if (c.backgroundUrl.isNotBlank()) {
            Images.load(c.backgroundUrl, bg, null)
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL

            setPadding(
                dp(20),
                dp(35),
                dp(20),
                dp(30)
            )
        }

        // HEADER BADGE
        val badge = TextView(this).apply {
            text = "✦  PREMIUM ACCESS SYSTEM  ✦"
            textSize = 9f
            letterSpacing = 0.13f
            gravity = Gravity.CENTER
            setTextColor(GREEN)
            setPadding(
                dp(14),
                dp(8),
                dp(14),
                dp(8)
            )

            background = roundedBg(
                0xFF102B2A.toInt(),
                dp(30).toFloat(),
                0xFF236F60.toInt(),
                dp(1)
            )
        }

        col.addView(
            badge,
            LinearLayout.LayoutParams(
                WRAP_CONTENT,
                WRAP_CONTENT
            )
        )

        gap(col, 22)

        // LOGO
        val ring = FrameLayout(this).apply {
            background = roundedBg(
                withAlpha(c.primary, 0.12f),
                dp(60).toFloat(),
                c.primary,
                dp(2)
            )

            setPadding(
                dp(11),
                dp(11),
                dp(11),
                dp(11)
            )
        }

        val logo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        Images.load(
            c.logoUrl,
            logo,
            R.drawable.logo_default
        )

        ring.addView(
            logo,
            FrameLayout.LayoutParams(
                MATCH_PARENT,
                MATCH_PARENT
            )
        )

        col.addView(
            ring,
            LinearLayout.LayoutParams(
                dp(108),
                dp(108)
            )
        )

        ring.fadeIn()

        gap(col, 14)

        // APP NAME
        col.addView(
            label(
                this,
                c.appName,
                25f,
                c.primary,
                true,
                true
            )
        )

        if (c.title.isNotBlank()) {
            gap(col, 5)

            col.addView(
                label(
                    this,
                    c.title,
                    14f,
                    c.text,
                    true,
                    true
                )
            )
        }

        if (c.description.isNotBlank()) {
            gap(col, 6)

            col.addView(
                label(
                    this,
                    c.description,
                    12f,
                    withAlpha(c.text, 0.65f),
                    false,
                    true
                )
            )
        }

        // BANNER
        if (
            c.showBanner &&
            c.bannerEnabled &&
            c.bannerUrl.isNotBlank()
        ) {
            gap(col, 17)

            val banner = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }

            Images.load(c.bannerUrl, banner, null)

            col.addView(
                banner,
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                )
            )
        }

        // ANNOUNCEMENT
        if (
            c.showAnnouncement &&
            c.announcement.isNotBlank()
        ) {
            gap(col, 16)

            val announcement = label(
                this,
                "📢  ${c.announcement}",
                12f,
                c.text
            )

            announcement.setPadding(
                dp(13),
                dp(12),
                dp(13),
                dp(12)
            )

            announcement.background = roundedBg(
                withAlpha(c.primary, 0.12f),
                dp(14).toFloat(),
                withAlpha(c.primary, 0.4f),
                dp(1)
            )

            col.addView(
                announcement,
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                )
            )
        }

        gap(col, 23)

        // KEY CARD
        val box = makeCard()

        val titleRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val keyIcon = TextView(this).apply {
            text = "🔐"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        titleRow.addView(
            keyIcon,
            LinearLayout.LayoutParams(
                dp(43),
                dp(43)
            )
        )

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), 0, 0, 0)
        }

        titleCol.addView(
            label(
                this,
                c.loginTitle,
                16f,
                c.text,
                true
            )
        )

        titleCol.addView(
            label(
                this,
                "KEY ACTIVATION",
                9f,
                GREEN,
                true
            ).apply {
                setPadding(0, dp(4), 0, 0)
            }
        )

        titleRow.addView(
            titleCol,
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            )
        )

        box.addView(titleRow)

        if (c.loginDesc.isNotBlank()) {
            gap(box, 9)

            box.addView(
                label(
                    this,
                    c.loginDesc,
                    12f,
                    withAlpha(c.text, 0.65f)
                )
            )
        }

        gap(box, 16)

        // KEY INPUT
        val inputWrap = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(
                dp(12),
                dp(2),
                dp(10),
                dp(2)
            )

            background = roundedBg(
                0xFF0A1121.toInt(),
                dp(14).toFloat(),
                withAlpha(c.primary, 0.65f),
                dp(1)
            )
        }

        inputWrap.addView(
            label(
                this,
                "KEY",
                10f,
                c.primary,
                true
            )
        )

        val et = EditText(this).apply {
            hint = c.loginHint
            setHintTextColor(withAlpha(c.text, 0.3f))
            setTextColor(c.text)
            textSize = 15f

            inputType =
                InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS

            filters = arrayOf(
                InputFilter.AllCaps(),
                InputFilter.LengthFilter(40)
            )

            setSingleLine(true)

            setPadding(
                dp(11),
                dp(13),
                dp(5),
                dp(13)
            )

            background = null

            setText(keyText)
            setSelection(keyText.length)
        }

        inputWrap.addView(
            et,
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            )
        )

        box.addView(
            inputWrap,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        // STATUS MESSAGE
        val status = label(
            this,
            if (busy) {
                "⏳ Đang xác thực KEY..."
            } else {
                msg
            },
            12f,
            if (busy) c.primary
            else if (msgOk) GREEN
            else RED
        )

        status.visibility =
            if (busy || msg.isNotEmpty()) {
                View.VISIBLE
            } else {
                View.GONE
            }

        gap(box, 10)
        box.addView(status)

        gap(box, 12)

        // ACTIVATE BUTTON
        val activateBtn = button(
            this,
            if (busy) {
                "⏳  ĐANG XÁC THỰC..."
            } else {
                "✦  ${c.loginButton}"
            },
            c.button,
            c.text
        ) {
            if (busy) return@button

            keyText = et.text.toString().trim()

            if (keyText.length < 16) {
                status.visibility = View.VISIBLE
                status.setTextColor(RED)
                status.text = "⚠ Vui lòng nhập KEY hợp lệ"
                return@button
            }

            activate(keyText)
        }

        activateBtn.textSize = 14f

        box.addView(
            activateBtn,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        gap(box, 9)

        // COPY BUTTON
        box.addView(
            button(
                this,
                "▣  SAO CHÉP KEY",
                0xFF202C43.toInt(),
                c.primary
            ) {
                val t = et.text.toString().trim()

                if (t.isEmpty()) {
                    Toast.makeText(
                        this,
                        "Chưa có KEY để sao chép",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    copyText(t)
                }
            },
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        col.addView(
            box,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        box.fadeIn(80)

        // ADMIN PROFILE
        if (
            c.adminName.isNotBlank() ||
            c.adminLinks.isNotEmpty()
        ) {
            gap(col, 15)

            val ad = makeCard()
            ad.gravity = Gravity.CENTER_HORIZONTAL

            val adminBadge = label(
                this,
                "HỖ TRỢ",
                10f,
                GREEN,
                true,
                true
            )

            ad.addView(adminBadge)

            if (c.adminAvatar.isNotBlank()) {
                gap(ad, 10)

                val av = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }

                circleClip(av)

                Images.load(
                    c.adminAvatar,
                    av,
                    null
                )

                ad.addView(
                    av,
                    LinearLayout.LayoutParams(
                        dp(75),
                        dp(75)
                    )
                )
            }

            if (c.adminName.isNotBlank()) {
                gap(ad, 9)

                ad.addView(
                    label(
                        this,
                        c.adminName,
                        16f,
                        c.text,
                        true,
                        true
                    )
                )
            }

            ad.addView(
                label(
                    this,
                    "✦ ADMIN",
                    10f,
                    c.primary,
                    true,
                    true
                )
            )

            if (c.adminBio.isNotBlank()) {
                gap(ad, 7)

                ad.addView(
                    label(
                        this,
                        c.adminBio,
                        12f,
                        withAlpha(c.text, 0.75f),
                        false,
                        true
                    )
                )
            }

            c.adminLinks.forEach { (l, u) ->
                gap(ad, 8)

                ad.addView(
                    button(
                        this,
                        "✉  $l",
                        withAlpha(c.primary, 0.16f),
                        c.primary
                    ) {
                        openUrl(this, u)
                    },
                    LinearLayout.LayoutParams(
                        MATCH_PARENT,
                        WRAP_CONTENT
                    )
                )
            }

            col.addView(
                ad,
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                )
            )

            ad.fadeIn(160)
        }

        // SHARE KEY FREE
        if (
            c.shareEnabled &&
            c.shareItems.isNotEmpty()
        ) {
            gap(col, 15)

            val sb = makeCard()

            sb.addView(
                label(
                    this,
                    "🎁  ${c.shareTitle}",
                    16f,
                    c.primary,
                    true
                )
            )

            if (c.shareDesc.isNotBlank()) {
                gap(sb, 5)

                sb.addView(
                    label(
                        this,
                        c.shareDesc,
                        12f,
                        withAlpha(c.text, 0.65f)
                    )
                )
            }

            c.shareItems.forEach { itemData ->
                gap(sb, 12)

                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL

                    setPadding(
                        dp(13),
                        dp(12),
                        dp(13),
                        dp(12)
                    )

                    background = roundedBg(
                        0xFF18243A.toInt(),
                        dp(13).toFloat(),
                        withAlpha(c.primary, 0.3f),
                        dp(1)
                    )
                }

                item.addView(
                    label(
                        this,
                        "✦  ${itemData.title}",
                        13f,
                        c.text,
                        true
                    )
                )

                if (itemData.content.isNotBlank()) {
                    gap(item, 5)

                    item.addView(
                        label(
                            this,
                            itemData.content,
                            13f,
                            c.primary
                        ).apply {
                            setTextIsSelectable(true)
                            setPadding(0, dp(4), 0, dp(4))
                        }
                    )
                }

                val row = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                }

                if (itemData.content.isNotBlank()) {
                    row.addView(
                        button(
                            this,
                            "▣ SAO CHÉP",
                            withAlpha(c.primary, 0.2f),
                            c.primary
                        ) {
                            copyText(itemData.content)
                        }.apply {
                            textSize = 11f
                        },
                        LinearLayout.LayoutParams(
                            0,
                            WRAP_CONTENT,
                            1f
                        ).apply {
                            rightMargin = dp(6)
                        }
                    )
                }

                if (itemData.link.isNotBlank()) {
                    row.addView(
                        button(
                            this,
                            "↗ MỞ LIÊN KẾT",
                            c.button,
                            c.text
                        ) {
                            openUrl(this@KeyActivity, itemData.link)
                        }.apply {
                            textSize = 11f
                        },
                        LinearLayout.LayoutParams(
                            0,
                            WRAP_CONTENT,
                            1f
                        )
                    )
                }

                item.addView(row)
                sb.addView(item)
            }

            col.addView(
                sb,
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                )
            )

            sb.fadeIn(240)
        }

        // SERVER STATUS
        if (c.showServerStatus) {
            gap(col, 18)

            val pair = when (online) {
                true ->
                    "● SERVER ONLINE" to GREEN

                false ->
                    "● SERVER OFFLINE" to RED

                null ->
                    "● ĐANG KẾT NỐI..." to 0xFFFFB020.toInt()
            }

            col.addView(
                label(
                    this,
                    pair.first,
                    11f,
                    pair.second,
                    true,
                    true
                )
            )
        }

        // FOOTER
        gap(col, 13)

        col.addView(
            label(
                this,
                "POWERED BY ${c.appName.uppercase()}",
                9f,
                GREY,
                true,
                true
            )
        )

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER

            addView(
                col,
                ViewGroup.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                )
            )
        }

        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                MATCH_PARENT,
                MATCH_PARENT
            )
        )

        setContentView(root)
    }

    // KEY ACTIVATION — GIỮ NGUYÊN API
    private fun activate(key: String) {
        busy = true
        msg = ""
        build()

        scope.launch {
            val r = Api.activate(
                key,
                Session.deviceId(this@KeyActivity),
                Build.MODEL ?: "Android"
            )

            busy = false

            if (r.net) {
                msg = "Không kết nối được Server. Kiểm tra mạng."
                msgOk = false
                online = false
                build()
                return@launch
            }

            if (r.ok && r.json.has("session")) {
                st.saveState(
                    r.json,
                    Session.bootCount(this@KeyActivity)
                )

                st.session = r.json.getString("session")

                goHome()
            } else {
                msgOk = false

                msg = if (
                    r.json.optString("status") == "EXPIRED"
                ) {
                    cfg.expiredMessage
                } else {
                    r.json.optString(
                        "error",
                        "Kích hoạt thất bại"
                    )
                }

                build()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

