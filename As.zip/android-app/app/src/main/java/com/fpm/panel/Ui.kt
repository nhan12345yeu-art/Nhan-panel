
package com.fpm.panel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import kotlin.math.roundToInt
import android.graphics.BitmapFactory
import android.widget.ImageView
import java.net.URL

private val CYAN = Color.rgb(0, 220, 255)
private val BLUE = Color.rgb(55, 105, 255)
private val PURPLE = Color.rgb(145, 75, 255)
private val DARK = Color.rgb(10, 13, 25)
private val SURFACE = Color.rgb(20, 25, 43)
private val MUTED = Color.rgb(145, 158, 185)

fun Context.dp(v: Int): Int =
    (v * resources.displayMetrics.density).roundToInt()

fun parseColor(s: String?, def: Int): Int {
    if (s.isNullOrBlank()) return def
    return try {
        Color.parseColor(if (s.startsWith("#")) s else "#$s")
    } catch (e: Exception) {
        def
    }
}

fun withAlpha(c: Int, a: Float): Int {
    return Color.argb(
        (a.coerceIn(0f, 1f) * 255).roundToInt(),
        Color.red(c),
        Color.green(c),
        Color.blue(c)
    )
}

fun roundedBg(
    fill: Int,
    radiusPx: Float,
    stroke: Int = 0,
    strokePx: Int = 0
): GradientDrawable {
    return GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtLeast(0f)
        setColor(fill)
        if (stroke != 0 && strokePx > 0) {
            setStroke(strokePx, stroke)
        }
    }
}

/** Trộn màu a → b theo tỉ lệ t (giữ alpha của a). */
fun blend(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.argb(
        Color.alpha(a),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).roundToInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).roundToInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).roundToInt()
    )
}

/** Bóng phát sáng (glow) theo màu; chỉ có tác dụng từ Android 9 trở lên, các bản thấp hơn dùng bóng thường. */
fun View.glow(color: Int, dpElevation: Int = 6) {
    elevation = context.dp(dpElevation).toFloat()
    if (Build.VERSION.SDK_INT >= 28) {
        outlineSpotShadowColor = withAlpha(color, 0.95f)
        outlineAmbientShadowColor = withAlpha(color, 0.55f)
    }
}

fun gradientBg(top: Int, bottom: Int): GradientDrawable {
    return GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(top, bottom)
    ).apply {
        shape = GradientDrawable.RECTANGLE
    }
}

fun darker(c: Int, f: Float = 0.45f): Int {
    val factor = f.coerceIn(0f, 1f)
    return Color.rgb(
        (Color.red(c) * factor).roundToInt(),
        (Color.green(c) * factor).roundToInt(),
        (Color.blue(c) * factor).roundToInt()
    )
}

fun fmtRemaining(ms: Long): String {
    if (ms <= 0) return "Đã hết hạn"

    val total = ms / 1000
    val days = total / 86400
    val hours = (total % 86400) / 3600
    val minutes = (total % 3600) / 60
    val seconds = total % 60

    return when {
        days > 0 -> "${days} ngày ${hours} giờ"
        hours > 0 -> "${hours} giờ ${minutes} phút"
        minutes > 0 -> "${minutes} phút ${seconds} giây"
        else -> "${seconds} giây"
    }
}

fun fmtDate(ms: Long?): String {
    if (ms == null || ms <= 0) return "Không xác định"

    return try {
        java.text.SimpleDateFormat(
            "HH:mm - dd/MM/yyyy",
            java.util.Locale("vi", "VN")
        ).format(java.util.Date(ms))
    } catch (e: Exception) {
        "Không xác định"
    }
}

fun View.press() {
    isClickable = true
    isFocusable = true

    setOnTouchListener { v, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                v.animate()
                    .scaleX(0.97f)
                    .scaleY(0.97f)
                    .setDuration(100)
                    .start()
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                v.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(130)
                    .start()
            }
        }
        false
    }
}

fun View.fadeIn(delay: Long = 0) {
    alpha = 0f
    translationY = 12f

    animate()
        .alpha(1f)
        .translationY(0f)
        .setStartDelay(delay)
        .setDuration(300)
        .setInterpolator(DecelerateInterpolator())
        .start()
}

fun circleClip(v: View) {
    v.background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.TRANSPARENT)
    }
    v.clipToOutline = true
}

fun openUrl(ctx: Context, url: String) {
    try {
        val uri = Uri.parse(url.trim())
        val scheme = uri.scheme?.lowercase() ?: return

        if (scheme != "https" && scheme != "http" && scheme != "tel") return

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun dial(ctx: Context, phone: String) {
    try {
        val intent = Intent(
            Intent.ACTION_DIAL,
            Uri.parse("tel:${Uri.encode(phone)}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun label(
    ctx: Context,
    text: String,
    sp: Float,
    color: Int,
    bold: Boolean = false,
    center: Boolean = false
): TextView {
    return TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        typeface = if (bold) {
            Typeface.create("sans-serif", Typeface.BOLD)
        } else {
            Typeface.create("sans-serif", Typeface.NORMAL)
        }

        gravity = if (center) Gravity.CENTER else Gravity.START
        includeFontPadding = false
        setLineSpacing(ctx.dp(3).toFloat(), 1f)
    }
}

fun button(
    ctx: Context,
    text: String,
    fill: Int,
    textColor: Int,
    onClick: () -> Unit
): TextView {
    return TextView(ctx).apply {
        this.text = text
        textSize = 14f
        setTextColor(textColor)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false

        setPadding(
            ctx.dp(18),
            ctx.dp(14),
            ctx.dp(18),
            ctx.dp(14)
        )

        // Nút gradient: sáng ở góc trái, đậm dần sang phải + viền sáng mảnh + glow cùng màu
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(blend(fill, Color.WHITE, 0.16f), darker(fill, 0.80f))
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ctx.dp(16).toFloat()
            setStroke(ctx.dp(1), withAlpha(Color.WHITE, 0.20f))
        }
        glow(fill, 5)

        setOnClickListener { onClick() }
        press()
    }
}

fun card(ctx: Context, cfg: AppConfig): LinearLayout {
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL

        // Viền gradient (primary → tím) + nền thẻ có chiều sâu. Đặt background TRƯỚC setPadding
        // vì LayerDrawable có inset sẽ ghi đè padding nếu đặt sau.
        val border = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(withAlpha(cfg.primary, 0.65f), withAlpha(PURPLE, 0.28f))
        ).apply { cornerRadius = ctx.dp(20).toFloat() }
        val body = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(blend(cfg.surface, Color.WHITE, 0.045f), blend(cfg.surface, Color.BLACK, 0.25f))
        ).apply { cornerRadius = ctx.dp(19).toFloat() }
        background = LayerDrawable(arrayOf(border, body)).apply {
            setLayerInset(1, ctx.dp(1), ctx.dp(1), ctx.dp(1), ctx.dp(1))
        }

        setPadding(
            ctx.dp(17),
            ctx.dp(16),
            ctx.dp(17),
            ctx.dp(16)
        )

        glow(cfg.primary, 4)
    }
}

fun LinearLayout.addGap(ctx: Context, h: Int) {
    addView(
        View(ctx),
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            ctx.dp(h)
        )
    )
}

class ToggleView(
    ctx: Context,
    checked: Boolean,
    accent: Int,
    onChanged: (Boolean) -> Unit
) : SwitchCompat(ctx) {

    init {
        isChecked = checked
        text = ""
        showText = false
        isClickable = true
        isFocusable = true

        thumbTintList = android.content.res.ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                Color.WHITE,
                Color.rgb(190, 198, 215)
            )
        )

        trackTintList = android.content.res.ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                withAlpha(accent, 0.92f),
                Color.rgb(52, 58, 82)
            )
        )

        setOnCheckedChangeListener { _, value ->
            onChanged(value)
        }
    }
}
object Images {

    fun load(
        imageUrl: String?,
        imageView: ImageView,
        fallbackRes: Int?
    ) {
        imageView.tag = imageUrl

        if (imageUrl.isNullOrBlank()) {
            if (fallbackRes != null) {
                imageView.setImageResource(fallbackRes)
            } else {
                imageView.setImageDrawable(null)
            }
            return
        }

        Thread {
            try {
                val connection = URL(imageUrl).openConnection()
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.connect()

                val bitmap = connection.getInputStream().use {
                    BitmapFactory.decodeStream(it)
                }

                imageView.post {
                    if (imageView.tag == imageUrl && bitmap != null) {
                        imageView.setImageBitmap(bitmap)
                    }
                }

                connection.getInputStream().close()
            } catch (_: Exception) {
                imageView.post {
                    if (imageView.tag == imageUrl && fallbackRes != null) {
                        imageView.setImageResource(fallbackRes)
                    }
                }
            }
        }.start()
    }
}
