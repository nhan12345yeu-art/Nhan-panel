package com.fpm.panel

import org.json.JSONObject

data class ShareItem(val title: String, val content: String, val link: String)

/** Cấu hình giao diện tải từ Server (/api/v1/config). Mọi giá trị đều có mặc định an toàn. */
class AppConfig(val raw: JSONObject) {
    companion object { fun default() = AppConfig(JSONObject()) }
    private fun o(k: String) = raw.optJSONObject(k) ?: JSONObject()
    val version get() = raw.optInt("version", 0)
    /** Đổi khi Admin lưu giao diện hoặc sửa nội dung Panel -> app tự tải lại. */
    val stamp get() = "${raw.optInt("version", 0)}:${raw.optLong("rev", 0)}"
    val appName get() = raw.optString("appName", "FLOATING PANEL PRO MAX")
    val title get() = raw.optString("title", "")
    val description get() = raw.optString("description", "")
    val announcement get() = raw.optString("announcement", "")
    val logoUrl get() = raw.optString("logoUrl", "")
    val panelLogoUrl get() = raw.optString("panelLogoUrl", "")
    val backgroundUrl get() = raw.optString("backgroundUrl", "")
    val panelBackgroundUrl get() = raw.optString("panelBackgroundUrl", "")
    val panelIntro get() = raw.optString("panelIntro", "")
    val bannerEnabled get() = o("banner").optBoolean("enabled", false)
    val bannerUrl get() = o("banner").optString("url", "")
    val expiredMessage get() = raw.optString("expiredMessage", "KEY của bạn đã hết hạn. Vui lòng nhập KEY mới.")
    val primary get() = parseColor(o("colors").optString("primary"), 0xFF18C8FF.toInt())
    val button get() = parseColor(o("colors").optString("button"), 0xFF2F7BFF.toInt())
    val text get() = parseColor(o("colors").optString("text"), 0xFFFFFFFF.toInt())
    val background get() = parseColor(o("colors").optString("background"), 0xFF05070D.toInt())
    val surface get() = parseColor(o("colors").optString("surface"), 0xFF0B1120.toInt())
    val loginTitle get() = o("login").optString("title", "KÍCH HOẠT KEY")
    val loginDesc get() = o("login").optString("description", "Nhập KEY được cấp để sử dụng.")
    val loginHint get() = o("login").optString("placeholder", "XXXXX-XXXXX-XXXXX-XXXXX")
    val loginButton get() = o("login").optString("buttonText", "XÁC NHẬN")
    private fun t(k: String) = o("toggles").optBoolean(k, true)
    val showBanner get() = t("showBanner"); val showAnnouncement get() = t("showAnnouncement")
    val showSettings get() = t("showSettingsButton"); val showServerStatus get() = t("showServerStatus"); val showCountdown get() = t("showCountdown")
    val panelOpacity get() = o("panel").optDouble("opacity", 0.92).toFloat()
    val panelRadius get() = o("panel").optInt("cornerRadius", 18)
    val panelWidth get() = o("panel").optInt("width", 300)
    val panelTitle get() = o("panel").optString("title", "PANEL")
    val adminName get() = o("adminProfile").optString("name", "")
    val adminAvatar get() = o("adminProfile").optString("avatarUrl", "")
    val adminBio get() = o("adminProfile").optString("bio", "")
    val adminLinks: List<Pair<String, String>> get() {
        val a = o("adminProfile").optJSONArray("links") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until a.length()) { val x = a.optJSONObject(i) ?: continue; out.add(Pair(x.optString("label"), x.optString("url"))) }
        return out
    }
    val contactPhone get() = o("contact").optString("phone", "0357924374")
    val contactZalo get() = o("contact").optString("zaloUrl", "")
    val contactMessage get() = o("contact").optString("message", "Nếu gặp lỗi hoặc cần hỗ trợ, vui lòng liên hệ Admin.")
    val shareEnabled get() = o("shareBox").optBoolean("enabled", true)
    val shareTitle get() = o("shareBox").optString("title", "BOX SHARE KEY FREE")
    val shareDesc get() = o("shareBox").optString("description", "")
    val shareItems: List<ShareItem> get() {
        val a = raw.optJSONArray("shareItems") ?: return emptyList()
        val out = ArrayList<ShareItem>()
        for (i in 0 until a.length()) { val x = a.optJSONObject(i) ?: continue; out.add(ShareItem(x.optString("title"), x.optString("content"), x.optString("link"))) }
        return out
    }
}
