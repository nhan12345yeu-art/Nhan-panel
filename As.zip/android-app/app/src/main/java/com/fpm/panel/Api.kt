package com.fpm.panel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Chỉ gọi các endpoint công khai /api/v1. Không có secret hay API quản trị trong APK. */
object Api {
    class Res(val code: Int, val json: JSONObject, val net: Boolean) { val ok get() = code in 200..299 && json.optBoolean("ok", true) }

    private fun call(method: String, path: String, body: JSONObject?, bearer: String?, device: String? = null): Res {
        var c: HttpURLConnection? = null
        return try {
            c = URL(BuildConfig.SERVER_URL + "/api/v1" + path).openConnection() as HttpURLConnection
            c.requestMethod = method; c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("Accept", "application/json")
            bearer?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            device?.let { c.setRequestProperty("X-Device-Id", it) }
            if (body != null) {
                c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            Res(code, try { JSONObject(txt) } catch (e: Exception) { JSONObject() }, false)
        } catch (e: Exception) { Res(0, JSONObject(), true) } finally { c?.disconnect() }
    }

    suspend fun config(): AppConfig? = withContext(Dispatchers.IO) {
        val r = call("GET", "/config", null, null); if (r.code == 200) AppConfig(r.json) else null
    }
    suspend fun activate(key: String, deviceId: String, model: String) = withContext(Dispatchers.IO) {
        call("POST", "/keys/activate", JSONObject().put("key", key).put("deviceId", deviceId).put("model", model), null)
    }
    suspend fun status(session: String, deviceId: String) = withContext(Dispatchers.IO) {
        call("POST", "/keys/status", JSONObject().put("deviceId", deviceId), session)
    }

    suspend fun panel(session: String, deviceId: String) = withContext(Dispatchers.IO) { call("GET", "/panel", null, session, deviceId) }
    suspend fun toggle(session: String, deviceId: String, id: Int, on: Boolean) = withContext(Dispatchers.IO) {
        call("POST", "/panel/features/$id/toggle", JSONObject().put("on", on), session, deviceId)
    }
    suspend fun run(session: String, deviceId: String, id: Int) = withContext(Dispatchers.IO) {
        call("POST", "/panel/features/$id/run", JSONObject(), session, deviceId)
    }
}
