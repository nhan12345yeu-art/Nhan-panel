package com.fpm.panel

import android.media.AudioAttributes
import android.media.MediaPlayer

/** Trình phát nhạc nền của Panel (chạy trong FloatingService). */
object MusicPlayer {
    private var mp: MediaPlayer? = null
    var tracks: List<Track> = emptyList(); private set
    var index = -1; private set
    var state = "stopped"; private set   // stopped | loading | playing | paused
    var volume = 0.7f; private set
    var onChange: (() -> Unit)? = null
    val title: String get() = tracks.getOrNull(index)?.title ?: ""

    fun updateTracks(list: List<Track>) {
        val curId = tracks.getOrNull(index)?.id
        tracks = list
        val ni = list.indexOfFirst { it.id == curId }
        if (curId != null && ni < 0) stop() else if (ni >= 0) index = ni
    }
    fun play(i: Int) {
        val t = tracks.getOrNull(i) ?: return
        release(); index = i; state = "loading"; onChange?.invoke()
        try {
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
                setDataSource(t.url); setVolume(volume, volume)
                setOnPreparedListener { it.start(); state = "playing"; onChange?.invoke() }
                setOnCompletionListener { next() }
                setOnErrorListener { _, _, _ -> release(); state = "stopped"; onChange?.invoke(); true }
                prepareAsync()
            }
        } catch (e: Exception) { release(); state = "stopped"; onChange?.invoke() }
    }
    fun playDefault() { if (tracks.isNotEmpty()) play(if (index in tracks.indices) index else 0) }
    fun pause() { mp?.takeIf { state == "playing" }?.let { it.pause(); state = "paused"; onChange?.invoke() } }
    fun resume() { mp?.takeIf { state == "paused" }?.let { it.start(); state = "playing"; onChange?.invoke() } }
    fun stop() { release(); state = "stopped"; onChange?.invoke() }
    fun next() { if (tracks.isNotEmpty()) play((index + 1) % tracks.size) }
    fun setVolume(v: Float) { volume = v.coerceIn(0f, 1f); mp?.setVolume(volume, volume) }
    private fun release() { try { mp?.release() } catch (e: Exception) { }; mp = null }
    fun shutdown() { release(); state = "stopped"; onChange = null }
}
