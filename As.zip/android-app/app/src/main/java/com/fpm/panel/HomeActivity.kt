package com.fpm.panel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

class HomeActivity : Activity() {

    private val scope = MainScope()
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var st: Store
    private var cfg = AppConfig.default()

    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var netTv: TextView

    private var online: Boolean? = null
    private var lastSync = 0L

    private val tick = object : Runnable {
        override fun run() {
            if (!::st.isInitialized) return
            updateCountdown()

            if (System.currentTimeMillis() - lastSync > 60_000) {
                syncNow()
            }

            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        st = Store.get(this)
        cfg = st.config()

        if (st.session == null) {
            startActivity(Intent(this, KeyActivity::class.java))
            finish()
            return
        }

        build()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1
            )
        }
    }

    override fun onResume() {
        super.onResume()

        if (::st.isInitialized && st.session != null) {
            handler.removeCallbacks(tick)
            handler.post(tick)
            refreshConfig()
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(tick)
        scope.cancel()
    }

    private fun build() {
        val c = cfg

        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    darker(c.background, 0.55f),
                    c.background,
                    Color.rgb(16, 22, 43)
                )
            )
        }

        // BACKGROUND IMAGE
        val bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.16f
        }

        root.addView(
            bg,
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        )

        Images.load(c.backgroundUrl, bg, null)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(20))
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(35), dp(20), dp(25))
        }

        scroll.addView(col)

        root.addView(
            scroll,
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        )

        // HEADER
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val logoFrame = FrameLayout(this).apply {
            background = roundedBg(
                withAlpha(c.primary, 0.15f),
                dp(17).toFloat(),
                withAlpha(c.primary, 0.55f),
                dp(1)
            )
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }

        val logo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        logoFrame.addView(
            logo,
            FrameLayout.LayoutParams(dp(45), dp(45))
        )

        Images.load(c.logoUrl, logo, R.drawable.logo_default)

        head.addView(
            logoFrame,
            LinearLayout.LayoutParams(dp(61), dp(61))
        )

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        brand.addView(label(this, c.appName, 19f, c.text, true))

        brand.addView(
            label(
                this,
                "PREMIUM CONTROL CENTER",
                9f,
                c.primary,
                true
            ).apply {
                setPadding(0, dp(5), 0, 0)
                letterSpacing = 0.12f
            }
        )

        head.addView(
            brand,
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )

        val version = label(
            this,
            "● LIVE",
            10f,
            Color.rgb(46, 229, 157),
            true,
            true
        ).apply {
            background = roundedBg(
                withAlpha(Color.rgb(46, 229, 157), 0.12f),
                dp(20).toFloat()
            )
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        head.addView(version)
        col.addView(head)

        col.addGap(this, 25)

        // WELCOME
        col.addView(
            label(this, "Xin chào, người dùng!", 23f, c.text, true)
        )

        col.addGap(this, 5)

        col.addView(
            label(
                this,
                "Quản lý và điều khiển hệ thống panel của bạn.",
                12f,
                withAlpha(c.text, 0.65f)
            )
        )

        col.addGap(this, 20)

        // BANNER
        if (c.showBanner && c.bannerEnabled && c.bannerUrl.isNotBlank()) {
            val bannerBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBg(
                    c.surface,
                    dp(17).toFloat(),
                    withAlpha(c.primary, 0.25f),
                    dp(1)
                )
                clipToOutline = true
            }

            val banner = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.CENTER_CROP
            }

            Images.load(c.bannerUrl, banner, null)

            bannerBox.addView(
                banner,
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            )

            col.addView(
                bannerBox,
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            )

            col.addGap(this, 15)
        }

        // ANNOUNCEMENT
        if (c.showAnnouncement && c.announcement.isNotBlank()) {
            val notice = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBg(
                    withAlpha(c.primary, 0.10f),
                    dp(14).toFloat(),
                    withAlpha(c.primary, 0.35f),
                    dp(1)
                )
                setPadding(dp(14), dp(13), dp(14), dp(13))
            }

            notice.addView(
                label(this, "📢  THÔNG BÁO", 11f, c.primary, true)
            )

            notice.addGap(this, 7)
            notice.addView(label(this, c.announcement, 12f, c.text))

            col.addView(notice)
            col.addGap(this, 20)
        }

        // KEY CARD
        val keyCard = card(this, c).apply {
            background = roundedBg(
                c.surface,
                dp(22).toFloat(),
                withAlpha(c.primary, 0.55f),
                dp(1)
            )
        }

        val keyHeader = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        keyHeader.addView(
            label(this, "◈  THÔNG TIN KEY", 13f, c.text, true),
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )

        val activeBadge = label(
            this,
            "● ACTIVE",
            10f,
            Color.rgb(46, 229, 157),
            true,
            true
        ).apply {
            background = roundedBg(
                withAlpha(Color.rgb(46, 229, 157), 0.12f),
                dp(20).toFloat()
            )
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }

        keyHeader.addView(activeBadge)
        keyCard.addView(keyHeader)

        keyCard.addGap(this, 20)

        keyCard.addView(
            label(
                this,
                "THỜI GIAN SỬ DỤNG CÒN LẠI",
                10f,
                withAlpha(c.text, 0.55f),
                true,
                true
            )
        )

        countTv = label(this, "--:--:--", 30f, c.primary, true, true).apply {
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            letterSpacing = 0.02f
        }

        keyCard.addView(
            countTv,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        keyCard.addGap(this, 15)

        // FIX DRAWABLE: dùng setBackgroundColor thay vì gán Int cho background
        val line = View(this).apply {
            setBackgroundColor(withAlpha(c.text, 0.12f))
        }

        keyCard.addView(
            line,
            LinearLayout.LayoutParams(MATCH_PARENT, dp(1))
        )

        keyCard.addGap(this, 13)

        statusTv = label(
            this,
            "",
            13f,
            Color.rgb(46, 229, 157),
            true
        )

        keyCard.addView(statusTv)
        keyCard.addGap(this, 12)

        addInfo(keyCard, "Ngày kích hoạt", fmtDate(st.activatedAt.takeIf { it > 0 }))
        addInfo(
            keyCard,
            "Ngày hết hạn",
            if (st.lifetime) "Vĩnh viễn" else fmtDate(st.expiresAt.takeIf { it > 0 })
        )
        addInfo(keyCard, "Gói KEY", st.plan)

        col.addView(
            keyCard,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addGap(this, 23)

        // CONTROL SECTION
        col.addView(label(this, "ĐIỀU KHIỂN PANEL", 13f, c.text, true))
        col.addGap(this, 12)

        addAction(
            col,
            "▶",
            "KHỞI ĐỘNG PANEL",
            "Bắt đầu hiển thị cửa sổ nổi",
            c.button,
            c.text
        ) {
            startPanel()
        }

        addAction(
            col,
            "■",
            "DỪNG PANEL",
            "Tắt cửa sổ nổi đang hoạt động",
            withAlpha(0xFFFF5470.toInt(), 0.16f),
            0xFFFF7185.toInt()
        ) {
            stopService(Intent(this, FloatingService::class.java))
            toast("Đã dừng panel")
        }

        addAction(
            col,
            "⟳",
            "LÀM MỚI / ĐỒNG BỘ",
            "Kiểm tra trạng thái và cập nhật dữ liệu",
            withAlpha(c.primary, 0.15f),
            c.primary
        ) {
            syncNow()
            refreshConfig(true)
        }

        if (c.showSettings) {
            addAction(
                col,
                "⚙",
                "CÀI ĐẶT GIAO DIỆN",
                "Tùy chỉnh kích thước và màu sắc panel",
                withAlpha(c.text, 0.09f),
                c.text
            ) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        }

        addAction(
            col,
            "⇥",
            "ĐĂNG XUẤT / ĐỔI KEY",
            "Quay lại màn hình kích hoạt",
            withAlpha(0xFFFF5470.toInt(), 0.10f),
            0xFFFF7185.toInt()
        ) {
            logoutKey()
        }

        col.addGap(this, 17)

        // SERVER STATUS
        val serverCard = card(this, c).apply {
            background = roundedBg(
                withAlpha(c.surface, 0.90f),
                dp(16).toFloat(),
                withAlpha(c.text, 0.10f),
                dp(1)
            )
        }

        serverCard.addView(
            label(this, "SERVER CONNECTION", 10f, withAlpha(c.text, 0.55f), true)
        )

        serverCard.addGap(this, 8)

        netTv = label(this, "● Đang kết nối...", 12f, c.text, true)
        serverCard.addView(netTv)

        if (c.showServerStatus) {
            col.addView(serverCard)
        }

        col.addGap(this, 20)

        col.addView(
            label(
                this,
                "${c.appName}  •  PREMIUM SYSTEM",
                10f,
                withAlpha(c.text, 0.4f),
                true,
                true
            )
        )

        setContentView(root)

        updateCountdown()
        updateNet()
    }

    private fun addInfo(parent: LinearLayout, title: String, value: String) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }

        row.addView(
            label(this, title, 11f, withAlpha(cfg.text, 0.58f)),
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )

        row.addView(label(this, value, 11f, cfg.text, true))
        parent.addView(row)
    }

    private fun addAction(
        parent: LinearLayout,
        icon: String,
        title: String,
        description: String,
        fill: Int,
        textColor: Int,
        action: () -> Unit
    ) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))

            background = roundedBg(
                fill,
                dp(16).toFloat(),
                withAlpha(textColor, 0.20f),
                dp(1)
            )

            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            press()
        }

        val iconView = label(this, icon, 20f, textColor, true, true).apply {
            background = roundedBg(
                withAlpha(textColor, 0.12f),
                dp(12).toFloat()
            )
        }

        item.addView(
            iconView,
            LinearLayout.LayoutParams(dp(43), dp(43))
        )

        val textBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        textBox.addView(label(this, title, 12f, textColor, true))
        textBox.addGap(this, 5)

        textBox.addView(
            label(this, description, 10f, withAlpha(cfg.text, 0.60f))
        )

        item.addView(
            textBox,
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )

        item.addView(
            label(this, "›", 23f, withAlpha(textColor, 0.7f), true)
        )

        parent.addView(
            item,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        parent.addGap(this, 10)
    }

    private fun updateNet() {
        if (!::netTv.isInitialized) return

        netTv.text = when (online) {
            true -> "● Đã kết nối Server"
            false -> "● Mất kết nối Server (chế độ tạm thời)"
            null -> "● Đang kết nối..."
        }

        netTv.setTextColor(
            when (online) {
                true -> 0xFF2EE59D.toInt()
                false -> 0xFFFFB020.toInt()
                null -> 0xFF8B96B5.toInt()
            }
        )
    }

    private fun updateCountdown() {
        if (!::statusTv.isInitialized) return

        val rem = st.remainingMs()
        val expired = rem != null && rem <= 0

        statusTv.text = if (expired) {
            "●  KEY ĐÃ HẾT HẠN"
        } else {
            "●  KEY ĐANG HOẠT ĐỘNG"
        }

        statusTv.setTextColor(
            if (expired) 0xFFFF5470.toInt()
            else 0xFF2EE59D.toInt()
        )

        countTv.text = when {
            st.lifetime -> "∞ VĨNH VIỄN"
            rem == null -> "--:--:--"
            else -> fmtRemaining(rem)
        }

        if (expired) {
            Session.lockAndExit(this, cfg.expiredMessage)
        }
    }

    private fun syncNow() {
        lastSync = System.currentTimeMillis()

        scope.launch {
            when (val s = Session.sync(this@HomeActivity)) {
                is Sync.Ok -> {
                    online = true
                    updateNet()
                    updateCountdown()
                }

                is Sync.Offline -> {
                    online = false
                    updateNet()

                    if (!st.canUseOffline(this@HomeActivity)) {
                        Session.lockAndExit(
                            this@HomeActivity,
                            "Cần kết nối Internet để xác thực KEY"
                        )
                    }
                }

                is Sync.Locked -> {
                    Session.lockAndExit(
                        this@HomeActivity,
                        if (s.status == "EXPIRED") cfg.expiredMessage else s.msg
                    )
                }
            }
        }
    }

    private fun refreshConfig(manual: Boolean = false) = scope.launch {
        val n = Api.config() ?: run {
            if (manual) toast("Không tải được cấu hình")
            return@launch
        }

        if (n.stamp != cfg.stamp) {
            st.saveConfig(n)
            cfg = n
            build()

            if (running()) {
                startService(
                    Intent(this@HomeActivity, FloatingService::class.java)
                        .setAction(FloatingService.ACTION_REFRESH)
                )
            }
        }

        if (manual) toast("Đã đồng bộ")
    }

    private fun logoutKey() {
        AlertDialog.Builder(this)
            .setTitle("Đăng xuất KEY")
            .setMessage(
                "Panel sẽ đóng và bạn quay về màn nhập KEY để dùng KEY khác. " +
                    "KEY hiện tại vẫn gắn với máy này."
            )
            .setPositiveButton("Đăng xuất") { _, _ ->
                stopService(Intent(this, FloatingService::class.java))
                st.clearSession()

                startActivity(
                    Intent(this, KeyActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
                    )
                )
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun running() = FloatingService.running

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    private fun startPanel() {
        val rem = st.remainingMs()

        if (rem != null && rem <= 0) {
            Session.lockAndExit(this, cfg.expiredMessage)
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Cấp quyền cửa sổ nổi")
                .setMessage(
                    "Để hiển thị panel trên các ứng dụng khác, hãy bật " +
                        "\"Hiển thị trên các ứng dụng khác\" cho ứng dụng này."
                )
                .setPositiveButton("Mở cài đặt") { _, _ ->
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
                .setNegativeButton("Hủy", null)
                .show()

            return
        }

        ContextCompat.startForegroundService(
            this,
            Intent(this, FloatingService::class.java)
        )

        toast("Đã khởi động panel")
    }
}