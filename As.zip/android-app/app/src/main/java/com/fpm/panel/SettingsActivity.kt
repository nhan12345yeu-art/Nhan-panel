package com.fpm.panel

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class SettingsActivity : Activity() {

    private val swatches = intArrayOf(
        0xFF00E5FF.toInt(),
        0xFF7C4DFF.toInt(),
        0xFF2EE59D.toInt(),
        0xFFFF5470.toInt(),
        0xFFFFB020.toInt(),
        0xFFFFFFFF.toInt(),
        0xFF141A2B.toInt(),
        0xFF000000.toInt()
    )

    private val dark = 0xFF080D19.toInt()
    private val surface = 0xFF111A2D.toInt()
    private val muted = 0xFF8995B2.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val cfg = Store.get(this).config()

        window.statusBarColor = dark
        window.navigationBarColor = dark

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(30), dp(20), dp(35))
        }

        col.addView(label(this, "CONTROL CENTER", 10f, 0xFF2EE59D.toInt(), true))
        col.addView(label(this, "Cài đặt Panel", 27f, Color.WHITE, true))
        col.addView(
            label(
                this,
                "Tùy chỉnh giao diện bảng điều khiển nổi của bạn.",
                12f,
                muted
            )
        )

        col.addGap(this, 22)

        // SIZE SETTINGS
        val sizeCard = makeCard()

        addSection(
            sizeCard,
            "01",
            "KÍCH THƯỚC & HIỂN THỊ",
            "Điều chỉnh kích thước và hình dạng panel"
        )

        sizeCard.addGap(this, 18)

        fun slider(
            title: String,
            description: String,
            min: Int,
            max: Int,
            current: Int,
            unit: String,
            onSet: (Int) -> Unit
        ) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
            }

            row.addView(
                label(this, title, 13f, Color.WHITE, true),
                LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            )

            val value = TextView(this).apply {
                text = "$current$unit"
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF00E5FF.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = roundedBg(0xFF102B39.toInt(), dp(9).toFloat())
            }

            row.addView(value)
            sizeCard.addView(row)
            sizeCard.addView(label(this, description, 10f, muted))

            val seek = SeekBar(this).apply {
                this.max = max - min
                progress = (current - min).coerceIn(0, max - min)
            }

            seek.setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(
                        s: SeekBar?,
                        progress: Int,
                        fromUser: Boolean
                    ) {
                        value.text = "${progress + min}$unit"
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}

                    override fun onStopTrackingTouch(s: SeekBar?) {
                        onSet(seek.progress + min)
                        apply()
                    }
                }
            )

            sizeCard.addView(
                seek,
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            )

            sizeCard.addGap(this, 15)
        }

        slider(
            "Chiều rộng panel",
            "Thay đổi chiều rộng bảng điều khiển.",
            180, 420,
            PanelPrefs.width(this, cfg.panelWidth),
            " dp"
        ) {
            PanelPrefs.put(this, "width", it)
        }

        slider(
            "Độ trong suốt",
            "Điều chỉnh mức độ nhìn xuyên nền.",
            30, 100,
            (PanelPrefs.opacity(this, cfg.panelOpacity) * 100).toInt(),
            "%"
        ) {
            PanelPrefs.put(this, "opacity", it / 100f)
        }

        slider(
            "Độ bo góc",
            "Tùy chỉnh độ cong các góc panel.",
            0, 40,
            PanelPrefs.radius(this, cfg.panelRadius),
            " dp"
        ) {
            PanelPrefs.put(this, "radius", it)
        }

        col.addView(
            sizeCard,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addGap(this, 16)

        // COLOR SETTINGS
        val colorCard = makeCard()

        addSection(
            colorCard,
            "02",
            "MÀU SẮC GIAO DIỆN",
            "Chọn màu nền và màu nhấn yêu thích"
        )

        colorCard.addGap(this, 18)

        fun swatchRow(title: String, key: String) {
            colorCard.addView(label(this, title, 13f, Color.WHITE, true))
            colorCard.addGap(this, 9)

            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }

            swatches.forEach { color ->
                val swatch = FrameLayout(this).apply {
                    background = roundedBg(
                        color,
                        dp(13).toFloat(),
                        0xFF56627D.toInt(),
                        dp(1)
                    )

                    elevation = dp(2).toFloat()

                    setOnClickListener {
                        PanelPrefs.put(this@SettingsActivity, key, color)
                        apply()
                        Toast.makeText(
                            this@SettingsActivity,
                            "Đã cập nhật màu sắc",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                row.addView(
                    swatch,
                    LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                        rightMargin = dp(9)
                    }
                )
            }

            colorCard.addView(
                HorizontalScrollView(this).apply {
                    isHorizontalScrollBarEnabled = false
                    addView(row)
                }
            )

            colorCard.addGap(this, 17)
        }

        swatchRow("Màu nền Panel", "bg")
        swatchRow("Màu nhấn / Accent", "accent")

        colorCard.addView(
            label(
                this,
                "Màu nhấn được sử dụng cho viền và các chi tiết nổi bật.",
                10f,
                muted
            )
        )

        col.addView(
            colorCard,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addGap(this, 16)

        // RESET SETTINGS
        val resetCard = makeCard()

        addSection(
            resetCard,
            "03",
            "KHÔI PHỤC",
            "Đưa toàn bộ tùy chỉnh về mặc định"
        )

        resetCard.addGap(this, 14)

        resetCard.addView(
            button(
                this,
                "↻   ĐẶT LẠI MẶC ĐỊNH",
                0xFF26334D.toInt(),
                Color.WHITE
            ) {
                PanelPrefs.reset(this)
                apply()
                Toast.makeText(
                    this,
                    "Đã khôi phục cài đặt",
                    Toast.LENGTH_SHORT
                ).show()
                recreate()
            },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addView(
            resetCard,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addGap(this, 16)

        // INFO
        val info = makeCard()

        info.addView(
            label(this, "✦  THÔNG TIN PANEL", 12f, 0xFF00E5FF.toInt(), true)
        )

        info.addGap(this, 8)

        info.addView(
            label(
                this,
                "Logo và hình nền Panel được cập nhật tự động từ máy chủ mỗi khi bạn mở ứng dụng hoặc bấm LÀM MỚI.",
                11f,
                muted
            )
        )

        col.addView(
            info,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        col.addGap(this, 22)

        col.addView(
            label(
                this,
                "CYBER PREMIUM  •  PANEL CONTROL",
                9f,
                muted,
                true,
                true
            )
        )

        scroll.addView(
            col,
            ViewGroup.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        )

        root.addView(
            scroll,
            LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        )

        setContentView(root)
        col.fadeIn()
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(17), dp(17), dp(17))

            background = roundedBg(
                surface,
                dp(19).toFloat(),
                0xFF293954.toInt(),
                dp(1)
            )
        }
    }

    private fun addSection(
        parent: LinearLayout,
        number: String,
        title: String,
        description: String
    ) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val numberView = TextView(this).apply {
            text = number
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF00E5FF.toInt())
            background = roundedBg(
                0xFF102B39.toInt(),
                dp(10).toFloat()
            )
        }

        row.addView(
            numberView,
            LinearLayout.LayoutParams(dp(39), dp(39))
        )

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, 0, 0)
        }

        texts.addView(label(this, title, 13f, Color.WHITE, true))
        texts.addView(label(this, description, 10f, muted))

        row.addView(
            texts,
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )

        parent.addView(row)
    }

    private fun apply() {
        if (FloatingService.running) {
            startService(
                Intent(this, FloatingService::class.java)
                    .setAction(FloatingService.ACTION_REFRESH)
            )
        }
    }
}