package com.fpm.panel

import org.json.JSONObject

class Section(val id: Int, val name: String, val icon: String, val desc: String, val kind: String, val content: String, val position: String)
class Feature(val id: Int, val sectionId: Int?, val name: String, val desc: String, val icon: String, var locked: Boolean, var on: Boolean, val hasAction: Boolean)
class Track(val id: Int, val title: String, val url: String)

/** Nội dung Panel do Admin cấu hình, lấy từ Server (/api/v1/panel). */
class PanelData(val sections: List<Section>, val features: List<Feature>, val tracks: List<Track>) {
    companion object {
        fun parse(j: JSONObject): PanelData {
            val s = ArrayList<Section>(); val f = ArrayList<Feature>(); val t = ArrayList<Track>()
            j.optJSONArray("sections")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { x ->
                s.add(Section(x.getInt("id"), x.optString("name"), x.optString("icon", "📁"), x.optString("description"), x.optString("kind", "text"), x.optString("content"), x.optString("position", "top"))) } }
            j.optJSONArray("features")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { x ->
                f.add(Feature(x.getInt("id"), if (x.isNull("sectionId")) null else x.getInt("sectionId"), x.optString("name"), x.optString("description"), x.optString("icon", "⚡"),
                    x.optBoolean("locked"), x.optBoolean("on"), x.optBoolean("hasAction"))) } }
            j.optJSONArray("tracks")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { x -> t.add(Track(x.getInt("id"), x.optString("title"), x.optString("url"))) } }
            return PanelData(s, f, t)
        }
    }
}
