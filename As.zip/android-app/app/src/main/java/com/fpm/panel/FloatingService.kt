package com.fpm.panel

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlin.math.abs

/** Floating Panel: nổi trên mọi ứng dụng, kéo thả, ẩn/hiện (chỉ còn logo), đóng hẳn, tự khóa khi KEY hết hạn. */
class FloatingService : Service() {
    companion object {
        const val ACTION_REFRESH = "com.fpm.panel.REFRESH"
        const val ACTION_STOP = "com.fpm.panel.STOP"
        private const val CH = "fpm_panel"
        @Volatile var running = false
    }
    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var panel: View? = null
    private var bubble: View? = null
    private var pp: WindowManager.LayoutParams? = null
    private var bp: WindowManager.LayoutParams? = null
    private var timerTv: TextView? = null
    private var ui: PanelUi? = null
    private var cfg = AppConfig.default()
    private var loopJob: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = NotificationChannel(CH, "Floating Panel", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, notification(), type)
        if (!Settings.canDrawOverlays(this) || Store.get(this).session == null) { stopSelf(); return }
        running = true
        PanelPrefs.expanded = true
        rebuild()
        startLoop()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) { ACTION_STOP -> stopSelf(); ACTION_REFRESH -> if (running) rebuild() }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, HomeActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH).setSmallIcon(R.drawable.ic_notif).setContentTitle("Panel đang chạy")
            .setContentIntent(open).addAction(0, "Dừng Panel", stop).setOngoing(true).build()
    }

    private fun overlayParams(w: Int): WindowManager.LayoutParams {
        val (x, y) = PanelPrefs.pos(this)
        return WindowManager.LayoutParams(w, WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y
        }
    }
    private fun safeRemove(v: View?) { try { if (v != null) wm.removeView(v) } catch (e: Exception) { } }

    private fun rebuild() {
        safeRemove(panel); safeRemove(bubble); panel = null; bubble = null
        cfg = Store.get(this).config()
        val accent = PanelPrefs.accent(this, cfg.primary); val bgc = PanelPrefs.bg(this, cfg.surface)
        val opacity = PanelPrefs.opacity(this, cfg.panelOpacity); val radius = dp(PanelPrefs.radius(this, cfg.panelRadius)).toFloat()
        val width = dp(PanelPrefs.width(this, cfg.panelWidth))

        // ---- Panel đầy đủ (nhiều mục, dữ liệu từ Server) ----
        ui?.dispose()
        val u = PanelUi(this, scope, cfg, accent, bgc, opacity, radius, { showBubble() }, { stopSelf() })
        ui = u; timerTv = u.timerTv; panel = u.root
        pp = overlayParams(width); drag(u.header, { pp!! }, { panel }, null)

        // ---- Logo nổi khi ẩn ----
        val b = ImageView(this).apply { setPadding(dp(6), dp(6), dp(6), dp(6)); background = roundedBg(withAlpha(bgc, 0.95f), dp(32).toFloat(), accent, dp(2)); scaleType = ImageView.ScaleType.FIT_CENTER }
        Images.load(cfg.panelLogoUrl, b, R.drawable.logo_panel)
        bp = overlayParams(dp(56)).apply { height = dp(56) }; drag(b, { bp!! }, { bubble }, { showPanel() }); bubble = b

        if (PanelPrefs.expanded) wm.addView(u.root, pp) else wm.addView(b, bp)
        updateTimer()
    }

    private fun showBubble() { // ẨN: chỉ còn logo
        val pv = panel ?: return; val bv = bubble ?: return
        bp!!.x = pp!!.x; bp!!.y = pp!!.y; safeRemove(pv); wm.addView(bv, bp); PanelPrefs.expanded = false
    }
    private fun showPanel() { // HIỆN: mở lại toàn bộ panel
        val pv = panel ?: return; val bv = bubble ?: return
        pp!!.x = bp!!.x; pp!!.y = bp!!.y; safeRemove(bv); wm.addView(pv, pp); PanelPrefs.expanded = true
    }

    private fun drag(handle: View, lp: () -> WindowManager.LayoutParams, target: () -> View?, onTap: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        handle.setOnTouchListener { _, e ->
            val l = lp()
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = l.x; sy = l.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        l.x = (sx + dx).coerceIn(0, (dm.widthPixels - dp(40)).coerceAtLeast(0)); l.y = (sy + dy).coerceIn(0, (dm.heightPixels - dp(60)).coerceAtLeast(0))
                        try { target()?.let { wm.updateViewLayout(it, l) } } catch (ex: Exception) { }
                    }; true
                }
                MotionEvent.ACTION_UP -> { if (moved) PanelPrefs.savePos(this, l.x, l.y) else onTap?.invoke(); true }
                else -> false
            }
        }
    }

    private fun updateTimer() {
        val rem = Store.get(this).remainingMs()
        timerTv?.text = if (rem == null) "KEY: ∞ Vĩnh viễn" else "KEY: " + fmtRemaining(rem)
    }

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = scope.launch {
            var tick = 0
            while (isActive) {
                val st = Store.get(this@FloatingService)
                val rem = st.remainingMs()
                if (rem != null && rem <= 0) { Session.lockAndExit(this@FloatingService, cfg.expiredMessage); return@launch }
                updateTimer()
                if (tick % 20 == 0 && tick > 0) ui?.refresh()
                if (tick % 30 == 0) { // kiểm tra KEY với Server mỗi 30 giây
                    when (val s = Session.sync(this@FloatingService)) {
                        is Sync.Locked -> { Session.lockAndExit(this@FloatingService, if (s.status == "EXPIRED") cfg.expiredMessage else s.msg); return@launch }
                        is Sync.Offline -> if (!st.canUseOffline(this@FloatingService)) { Session.lockAndExit(this@FloatingService, "Cần kết nối Internet để xác thực KEY"); return@launch }
                        else -> {}
                    }
                }
                tick++; delay(1000)
            }
        }
    }

    override fun onDestroy() {
        running = false; MusicPlayer.shutdown(); ui?.dispose(); scope.cancel(); safeRemove(panel); safeRemove(bubble); super.onDestroy()
    }
}
