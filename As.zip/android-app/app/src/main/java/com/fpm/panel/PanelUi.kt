package com.fpm.panel

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class PanelUi(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val cfg: AppConfig,
    private val accent: Int,
    bgColor: Int,
    opacity: Float,
    radiusPx: Float,
    onHide: () -> Unit,
    onClose: () -> Unit
) {

    private class MaxHeightScroll(
        c: Context,
        private val maxH: Int
    ) : ScrollView(c) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(
                w,
                MeasureSpec.makeMeasureSpec(
                    maxH,
                    MeasureSpec.AT_MOST
                )
            )
        }
    }

    // CYBER PREMIUM COLORS
    private val GREEN = 0xFF25F5B2.toInt()
    private val GREY = 0xFF8995B2.toInt()
    private val PURPLE = 0xFF9666FF.toInt()
    private val BLUE = 0xFF318BFF.toInt()
    private val DARK = 0xFF080D19.toInt()
    private val SURFACE = 0xFF11192A.toInt()
    private val WHITE = Color.WHITE
    private val RED = 0xFFFF5577.toInt()

    private val st = Store.get(ctx)
    private val devId = Session.deviceId(ctx)

    private var data: PanelData? = null
    private var lastRaw = ""
    private var selected = -1

    val root = FrameLayout(ctx)
    val header = LinearLayout(ctx)
    val timerTv: TextView = label(ctx, "", 10f, GREEN)

    private val topBar = LinearLayout(ctx)
    private val bottomBar = LinearLayout(ctx)
    private val topScroll = HorizontalScrollView(ctx)
    private val bottomScroll = HorizontalScrollView(ctx)
    private val content = LinearLayout(ctx)
    private val footer = LinearLayout(ctx)

    init {
        root.background = roundedBg(
            withAlpha(bgColor, opacity),
            radiusPx,
            withAlpha(PURPLE, 0.85f),
            ctx.dp(1)
        )
        root.clipToOutline = true

        // BACKGROUND IMAGE
        if (cfg.panelBackgroundUrl.isNotBlank()) {
            val bg = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = 0.16f
            }

            root.addView(
                bg,
                FrameLayout.LayoutParams(
                    MATCH_PARENT,
                    MATCH_PARENT
                )
            )

            Images.load(
                cfg.panelBackgroundUrl,
                bg,
                null
            )
        }

        // MAIN CONTAINER
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                ctx.dp(13),
                ctx.dp(13),
                ctx.dp(13),
                ctx.dp(11)
            )
        }

        // HEADER
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(
            0,
            ctx.dp(2),
            0,
            ctx.dp(12)
        )

        val logoBox = FrameLayout(ctx).apply {
            background = roundedBg(
                withAlpha(PURPLE, 0.18f),
                ctx.dp(15).toFloat(),
                withAlpha(PURPLE, 0.65f),
                ctx.dp(1)
            )
        }

        val logo = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        Images.load(
            cfg.panelLogoUrl,
            logo,
            R.drawable.logo_panel
        )

        logoBox.addView(
            logo,
            FrameLayout.LayoutParams(
                ctx.dp(42),
                ctx.dp(42)
            ).apply {
                gravity = Gravity.CENTER
            }
        )

        header.addView(
            logoBox,
            LinearLayout.LayoutParams(
                ctx.dp(48),
                ctx.dp(48)
            )
        )

        val titles = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                ctx.dp(11),
                ctx.dp(2),
                ctx.dp(4),
                0
            )
        }

        titles.addView(
            label(
                ctx,
                cfg.panelTitle.ifBlank { "PANEL" },
                15f,
                WHITE,
                true
            )
        )

        titles.addView(
            timerTv.apply {
                setPadding(0, ctx.dp(3), 0, 0)
            }
        )

        header.addView(
            titles,
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            )
        )

        header.addView(iconBtn("−", PURPLE, onHide))
        header.addView(iconBtn("✕", RED, onClose))

        col.addView(header)

        // STATUS CARD
        val status = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(
                ctx.dp(12),
                ctx.dp(10),
                ctx.dp(12),
                ctx.dp(10)
            )

            background = roundedBg(
                0xFF101D2C.toInt(),
                ctx.dp(13).toFloat(),
                0xFF254B65.toInt(),
                ctx.dp(1)
            )
        }

        status.addView(
            label(ctx, "●", 11f, GREEN, true)
        )

        status.addView(
            label(ctx, " SYSTEM ONLINE", 10f, GREEN, true).apply {
                setPadding(ctx.dp(6), 0, 0, 0)
            }
        )

        status.addView(
            View(ctx),
            LinearLayout.LayoutParams(0, 1, 1f)
        )

        status.addView(
            label(ctx, "PREMIUM EDITION", 9f, GREY, true)
        )

        col.addView(
            status,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            ).apply {
                bottomMargin = ctx.dp(9)
            }
        )

        // INTRO FROM ADMIN
        if (cfg.panelIntro.isNotBlank()) {
            col.addView(
                label(
                    ctx,
                    cfg.panelIntro,
                    11f,
                    withAlpha(cfg.text, 0.8f)
                ).apply {
                    setPadding(
                        ctx.dp(3),
                        ctx.dp(2),
                        ctx.dp(3),
                        ctx.dp(9)
                    )
                }
            )
        }

        // NAVIGATION
        topBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.orientation = LinearLayout.HORIZONTAL

        topScroll.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        bottomScroll.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        topScroll.addView(topBar)
        bottomScroll.addView(bottomBar)

        col.addView(
            topScroll,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        // CONTENT
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(
            0,
            ctx.dp(12),
            0,
            ctx.dp(9)
        )

        val maxHeight = (
            ctx.resources.displayMetrics.heightPixels * 0.42f
        ).toInt()

        val scroll = MaxHeightScroll(
            ctx,
            maxHeight
        ).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }

        col.addView(
            scroll,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        col.addView(
            bottomScroll,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        // CONTACT FOOTER
        footer.orientation = LinearLayout.VERTICAL
        footer.setPadding(
            0,
            ctx.dp(9),
            0,
            0
        )

        val line = View(ctx).apply {
            background = gradientBg(PURPLE, BLUE)
        }

        footer.addView(
            line,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                ctx.dp(1)
            )
        )

        val contact = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(
                ctx.dp(8),
                ctx.dp(10),
                ctx.dp(5),
                ctx.dp(3)
            )
        }

        val contactInfo = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }

        contactInfo.addView(
            label(ctx, "ADMIN SUPPORT", 9f, GREY, true)
        )

        contactInfo.addView(
            label(ctx, "Hỗ trợ khách hàng", 11f, WHITE, true).apply {
                setPadding(0, ctx.dp(3), 0, 0)
            }
        )

        contact.addView(
            contactInfo,
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            )
        )

        val contactBtn = button(
            ctx,
            "✦ LIÊN HỆ ADMIN",
            0xFF286DFF.toInt(),
            WHITE
        ) {
            openAdminContact()
        }

        contactBtn.textSize = 10f

        contact.addView(
            contactBtn,
            LinearLayout.LayoutParams(
                WRAP_CONTENT,
                WRAP_CONTENT
            )
        )

        footer.addView(contact)
        col.addView(footer)

        root.addView(
            col,
            FrameLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        // LOAD CACHED PANEL
        st.panelRaw()?.let {
            try {
                apply(JSONObject(it))
            } catch (_: Exception) {
            }
        }

        // MUSIC CALLBACK
        MusicPlayer.onChange = {
            if (currentKind() == "music") {
                renderContent()
            }
        }

        refresh()
    }

    // CONTACT URL - ZALO ONLY
    private fun openAdminContact() {
        val configured = cfg.contactZalo.trim()

        val zalo = when {
            configured.startsWith("https://") ||
                configured.startsWith("http://") ->
                configured

            configured.startsWith("zalo.me/") ->
                "https://$configured"

            configured.isNotBlank() -> {
                val digits = configured.filter { it.isDigit() }

                if (digits.isNotBlank() && digits == configured) {
                    "https://zalo.me/$digits"
                } else {
                    "https://$configured"
                }
            }

            else -> {
                val phone = cfg.contactPhone.filter {
                    it.isDigit()
                }

                "https://zalo.me/${phone.ifBlank { "0357924364" }}"
            }
        }

        openUrl(ctx, zalo)
    }

    // UI HELPERS
    private fun iconBtn(
        t: String,
        color: Int,
        f: () -> Unit
    ) = TextView(ctx).apply {
        text = t
        textSize = 17f
        setTextColor(color)
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)

        layoutParams = LinearLayout.LayoutParams(
            ctx.dp(35),
            ctx.dp(35)
        ).apply {
            leftMargin = ctx.dp(5)
        }

        background = roundedBg(
            withAlpha(color, 0.13f),
            ctx.dp(11).toFloat(),
            withAlpha(color, 0.3f),
            ctx.dp(1)
        )

        setOnClickListener { f() }
        press()
    }

    private fun sectionTitle(text: String): View {
        return label(
            ctx,
            text.uppercase(),
            10f,
            PURPLE,
            true
        ).apply {
            setPadding(
                ctx.dp(3),
                ctx.dp(2),
                0,
                ctx.dp(8)
            )
        }
    }

    private fun divider(): View {
        return View(ctx).apply {
            setBackgroundColor(withAlpha(PURPLE, 0.35f))
        }
    }

    // SERVER
    fun refresh() {
        scope.launch {
            val s = st.session ?: return@launch
            val r = Api.panel(s, devId)

            if (r.ok) {
                r.json.remove("serverTime")

                val raw = r.json.toString()

                if (raw != lastRaw) {
                    st.savePanel(raw)
                    apply(r.json)
                }
            }
        }
    }

    private fun apply(j: JSONObject) {
        lastRaw = j.toString()
        data = PanelData.parse(j)

        MusicPlayer.updateTracks(data!!.tracks)

        if (data!!.sections.none {
                it.id == selected
            }
        ) {
            selected = data!!.sections.firstOrNull()?.id ?: -1
        }

        renderNav()
        renderContent()
    }

    private fun currentKind() =
        data?.sections?.firstOrNull {
            it.id == selected
        }?.kind

    // NAVIGATION
    private fun renderNav() {
        val d = data ?: return

        topBar.removeAllViews()
        bottomBar.removeAllViews()

        d.sections.forEach { s ->
            val target =
                if (s.position == "bottom") bottomBar
                else topBar

            target.addView(
                chip(s),
                LinearLayout.LayoutParams(
                    WRAP_CONTENT,
                    WRAP_CONTENT
                ).apply {
                    rightMargin = ctx.dp(7)
                }
            )
        }

        topScroll.visibility =
            if (topBar.childCount == 0) View.GONE
            else View.VISIBLE

        bottomScroll.visibility =
            if (bottomBar.childCount == 0) View.GONE
            else View.VISIBLE
    }

    private fun chip(s: Section) =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER

            setPadding(
                ctx.dp(15),
                ctx.dp(10),
                ctx.dp(15),
                ctx.dp(10)
            )

            val sel = s.id == selected

            background = roundedBg(
                if (sel) withAlpha(PURPLE, 0.22f)
                else 0xFF111827.toInt(),
                ctx.dp(13).toFloat(),
                if (sel) PURPLE else 0xFF28334A.toInt(),
                ctx.dp(1)
            )

            addView(
                label(
                    ctx,
                    s.icon,
                    17f,
                    if (sel) PURPLE else GREY,
                    false,
                    true
                )
            )

            addView(
                label(
                    ctx,
                    s.name,
                    10f,
                    if (sel) WHITE else GREY,
                    true,
                    true
                ).apply {
                    setPadding(0, ctx.dp(3), 0, 0)
                }
            )

            setOnClickListener {
                selected = s.id
                renderNav()
                renderContent()
            }

            press()
        }

    // CONTENT
    private fun renderContent() {
        val d = data ?: return

        val s = d.sections.firstOrNull {
            it.id == selected
        }

        content.removeAllViews()

        if (s == null) {
            content.addView(
                label(
                    ctx,
                    "Chưa có mục nào trên Panel.",
                    12f,
                    GREY,
                    false,
                    true
                )
            )
            return
        }

        if (s.desc.isNotBlank()) {
            content.addView(
                label(
                    ctx,
                    s.desc,
                    11f,
                    withAlpha(cfg.text, 0.7f)
                ).apply {
                    setPadding(
                        ctx.dp(3),
                        0,
                        ctx.dp(3),
                        ctx.dp(9)
                    )
                }
            )
        }

        when (s.kind) {
            "features" -> renderFeatures(d, s)
            "music" -> renderMusic()
            "contact" -> renderContact()

            else -> {
                val textBox = card(ctx, cfg).apply {
                    background = roundedBg(
                        SURFACE,
                        ctx.dp(15).toFloat(),
                        0xFF293653.toInt(),
                        ctx.dp(1)
                    )
                }

                textBox.addView(
                    label(
                        ctx,
                        s.content.ifBlank {
                            "Chưa có nội dung."
                        },
                        13f,
                        cfg.text
                    ).apply {
                        setTextIsSelectable(true)
                        setPadding(
                            ctx.dp(3),
                            ctx.dp(3),
                            ctx.dp(3),
                            ctx.dp(3)
                        )
                    }
                )

                content.addView(
                    textBox,
                    LinearLayout.LayoutParams(
                        MATCH_PARENT,
                        WRAP_CONTENT
                    )
                )
            }
        }

        content.fadeIn()
    }

    // FEATURES
    private fun renderFeatures(
        d: PanelData,
        s: Section
    ) {
        val first = d.sections.firstOrNull {
            it.kind == "features"
        }?.id

        val list = d.features.filter {
            it.sectionId == s.id ||
                (
                    it.sectionId == null &&
                        s.id == first
                )
        }

        if (list.isEmpty()) {
            content.addView(
                label(
                    ctx,
                    "Chưa có chức năng nào.",
                    12f,
                    GREY,
                    false,
                    true
                )
            )
            return
        }

        list.forEach { f ->
            content.addView(
                featureRow(f),
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                ).apply {
                    bottomMargin = ctx.dp(8)
                }
            )
        }
    }

    private fun featureRow(f: Feature): View {
        val on = f.on && !f.locked

        val row = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL

            setPadding(
                ctx.dp(13),
                ctx.dp(13),
                ctx.dp(12),
                ctx.dp(13)
            )

            background = roundedBg(
                when {
                    f.locked -> 0xFF141827.toInt()
                    on -> 0xFF102B2A.toInt()
                    else -> SURFACE
                },
                ctx.dp(16).toFloat(),
                when {
                    f.locked -> 0xFF34394A.toInt()
                    on -> GREEN
                    else -> 0xFF293650.toInt()
                },
                ctx.dp(1)
            )

            press()
        }

        val iconBox = FrameLayout(ctx).apply {
            background = roundedBg(
                withAlpha(
                    if (on) GREEN else PURPLE,
                    0.13f
                ),
                ctx.dp(12).toFloat()
            )
        }

        val iconView = label(
            ctx,
            if (f.locked) "🔒" else f.icon,
            20f,
            if (on) GREEN else WHITE,
            false,
            true
        )

        iconBox.addView(
            iconView,
            FrameLayout.LayoutParams(
                ctx.dp(40),
                ctx.dp(40)
            )
        )

        row.addView(
            iconBox,
            LinearLayout.LayoutParams(
                ctx.dp(40),
                ctx.dp(40)
            )
        )

        val tx = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                ctx.dp(9),
                0,
                ctx.dp(6),
                0
            )
        }

        tx.addView(
            label(
                ctx,
                f.name,
                13f,
                when {
                    f.locked -> GREY
                    on -> GREEN
                    else -> WHITE
                },
                true
            )
        )

        val sub = when {
            f.locked -> "Đã bị Admin khóa"
            f.desc.isNotBlank() -> f.desc
            on -> "Đang hoạt động"
            else -> "Sẵn sàng kích hoạt"
        }

        tx.addView(
            label(ctx, sub, 10f, GREY).apply {
                setPadding(0, ctx.dp(4), 0, 0)
            }
        )

        row.addView(
            tx,
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            )
        )

        // ANDROID NATIVE SWITCH
        val tg = Switch(ctx).apply {
            isChecked = on
            isEnabled = !f.locked
            showText = false
            contentDescription = "Bật hoặc tắt ${f.name}"
        }

        tg.setOnCheckedChangeListener { _, checked ->
            if (checked != f.on) {
                toggle(f)
            }
        }

        row.addView(
            tg,
            LinearLayout.LayoutParams(
                WRAP_CONTENT,
                WRAP_CONTENT
            )
        )

        row.setOnClickListener {
            when {
                f.locked ->
                    toast("Chức năng đã bị Admin khóa")

                !f.on ->
                    toast("Hãy bật công tắc để sử dụng")

                f.hasAction ->
                    runFeature(f)

                else ->
                    toast("Chức năng \"${f.name}\" đang bật")
            }
        }

        return row
    }

    private fun toggle(f: Feature) {
        if (f.locked) {
            toast("Chức năng đã bị Admin khóa")
            return
        }

        scope.launch {
            val s = st.session ?: return@launch

            val r = Api.toggle(
                s,
                devId,
                f.id,
                !f.on
            )

            when {
                r.net -> toast("Không kết nối được Server")

                r.json.optBoolean("locked") -> {
                    toast(
                        r.json.optString(
                            "error",
                            "Chức năng đã bị khóa"
                        )
                    )
                    lastRaw = ""
                    refresh()
                }

                r.ok -> {
                    f.on = r.json.optBoolean("on")
                    renderContent()
                }

                else -> toast(
                    r.json.optString(
                        "error",
                        "Thao tác thất bại"
                    )
                )
            }
        }
    }

    private fun runFeature(f: Feature) {
        scope.launch {
            val s = st.session ?: return@launch

            val r = Api.run(s, devId, f.id)

            if (r.net) {
                toast("Không kết nối được Server")
                return@launch
            }

            if (!r.ok) {
                toast(
                    r.json.optString(
                        "error",
                        "Không thể thực hiện"
                    )
                )
                lastRaw = ""
                refresh()
                return@launch
            }

            val a = r.json.optJSONObject("action")
                ?: return@launch

            val v = a.optString("value")

            when (a.optString("type")) {
                "link" -> openUrl(ctx, v)
                "call" -> dial(ctx, v)
                "toast" -> toast(v)
                else -> toast("Đã thực hiện: ${f.name}")
            }
        }
    }

    // MUSIC PLAYER
    private fun renderMusic() {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                ctx.dp(15),
                ctx.dp(15),
                ctx.dp(15),
                ctx.dp(14)
            )

            background = roundedBg(
                0xFF111A2D.toInt(),
                ctx.dp(18).toFloat(),
                0xFF6753A7.toInt(),
                ctx.dp(1)
            )
        }

        val state = MusicPlayer.state

        val name = when {
            MusicPlayer.title.isBlank() ->
                "Chưa phát bài nào"

            state == "loading" ->
                "Đang tải: ${MusicPlayer.title}"

            else -> MusicPlayer.title
        }

        box.addView(
            label(
                ctx,
                "♫  $name",
                14f,
                PURPLE,
                true
            ).apply {
                setSingleLine(true)
                ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
                isSelected = true
            }
        )

        box.addView(
            label(
                ctx,
                when (state) {
                    "playing" -> "● ĐANG PHÁT"
                    "paused" -> "● TẠM DỪNG"
                    "loading" -> "● ĐANG TẢI..."
                    else -> "● ĐÃ TẮT"
                },
                10f,
                if (state == "playing") GREEN else GREY,
                true
            ).apply {
                setPadding(
                    0,
                    ctx.dp(6),
                    0,
                    ctx.dp(12)
                )
            }
        )

        val r1 = LinearLayout(ctx)
        val r2 = LinearLayout(ctx)

        fun mb(
            t: String,
            enabled: Boolean,
            f: () -> Unit
        ) = button(
            ctx,
            t,
            if (enabled) 0xFF29345D.toInt()
            else 0xFF1B2433.toInt(),
            if (enabled) WHITE else GREY
        ) {
            if (enabled) f()
        }.apply {
            textSize = 10f
            setPadding(
                ctx.dp(5),
                ctx.dp(12),
                ctx.dp(5),
                ctx.dp(12)
            )
        }

        val lp = {
            LinearLayout.LayoutParams(
                0,
                WRAP_CONTENT,
                1f
            ).apply {
                setMargins(
                    ctx.dp(3),
                    ctx.dp(3),
                    ctx.dp(3),
                    ctx.dp(3)
                )
            }
        }

        r1.addView(
            mb(
                "▶ PHÁT",
                MusicPlayer.tracks.isNotEmpty() &&
                    state != "playing"
            ) {
                MusicPlayer.playDefault()
            },
            lp()
        )

        r1.addView(
            mb("⏸ DỪNG", state == "playing") {
                MusicPlayer.pause()
            },
            lp()
        )

        r2.addView(
            mb("⏯ TIẾP TỤC", state == "paused") {
                MusicPlayer.resume()
            },
            lp()
        )

        r2.addView(
            mb("⏹ TẮT NHẠC", state != "stopped") {
                MusicPlayer.stop()
            },
            lp()
        )

        box.addView(r1)
        box.addView(r2)

        box.addView(
            label(ctx, "ÂM LƯỢNG", 10f, GREY, true).apply {
                setPadding(
                    ctx.dp(2),
                    ctx.dp(10),
                    0,
                    0
                )
            }
        )

        val sb = SeekBar(ctx).apply {
            max = 100
            progress = (MusicPlayer.volume * 100).toInt()
        }

        sb.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    s: SeekBar?,
                    p: Int,
                    u: Boolean
                ) {
                    if (u) MusicPlayer.setVolume(p / 100f)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }
        )

        box.addView(sb)

        content.addView(
            box,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        content.addView(sectionTitle("Danh sách phát"))

        if (MusicPlayer.tracks.isEmpty()) {
            content.addView(
                label(
                    ctx,
                    "Admin chưa thêm bài hát nào.",
                    11f,
                    GREY,
                    false,
                    true
                ).apply {
                    setPadding(
                        0,
                        ctx.dp(8),
                        0,
                        ctx.dp(8)
                    )
                }
            )
        }

        MusicPlayer.tracks.forEachIndexed { i, t ->
            val cur =
                i == MusicPlayer.index &&
                    MusicPlayer.state != "stopped"

            content.addView(
                label(
                    ctx,
                    (if (cur) "▶  " else "${i + 1}.  ") + t.title,
                    12f,
                    if (cur) GREEN else WHITE,
                    cur
                ).apply {
                    setPadding(
                        ctx.dp(13),
                        ctx.dp(13),
                        ctx.dp(12),
                        ctx.dp(13)
                    )

                    background = roundedBg(
                        if (cur) 0xFF12302F.toInt() else SURFACE,
                        ctx.dp(13).toFloat(),
                        if (cur) GREEN else 0xFF29334A.toInt(),
                        ctx.dp(1)
                    )

                    setSingleLine(true)

                    setOnClickListener {
                        MusicPlayer.play(i)
                    }

                    press()
                },
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                ).apply {
                    topMargin = ctx.dp(6)
                }
            )
        }
    }

    // CONTACT PAGE - ZALO ONLY
    private fun renderContact() {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL

            setPadding(
                ctx.dp(17),
                ctx.dp(20),
                ctx.dp(17),
                ctx.dp(19)
            )

            background = roundedBg(
                0xFF121B30.toInt(),
                ctx.dp(19).toFloat(),
                withAlpha(BLUE, 0.8f),
                ctx.dp(1)
            )
        }

        val iconBox = FrameLayout(ctx).apply {
            background = roundedBg(
                withAlpha(BLUE, 0.16f),
                ctx.dp(18).toFloat()
            )
        }

        iconBox.addView(
            label(
                ctx,
                "✦",
                30f,
                BLUE,
                true,
                true
            ),
            FrameLayout.LayoutParams(
                ctx.dp(65),
                ctx.dp(65)
            )
        )

        box.addView(
            iconBox,
            LinearLayout.LayoutParams(
                ctx.dp(65),
                ctx.dp(65)
            )
        )

        box.addView(
            label(
                ctx,
                "LIÊN HỆ ADMIN",
                16f,
                WHITE,
                true,
                true
            ).apply {
                setPadding(
                    0,
                    ctx.dp(13),
                    0,
                    0
                )
            }
        )

        box.addView(
            label(
                ctx,
                cfg.contactMessage.ifBlank {
                    "Bạn cần hỗ trợ? Admin luôn sẵn sàng!"
                },
                11f,
                GREY,
                false,
                true
            ).apply {
                setPadding(
                    ctx.dp(3),
                    ctx.dp(7),
                    ctx.dp(3),
                    ctx.dp(15)
                )
            }
        )

        box.addView(
            button(
                ctx,
                "💬  NHẮN TIN QUA ZALO",
                0xFF2478FF.toInt(),
                WHITE
            ) {
                openAdminContact()
            },
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )

        if (cfg.contactPhone.isNotBlank()) {
            box.addView(
                button(
                    ctx,
                    "☎  GỌI ĐIỆN ADMIN",
                    0xFF202C43.toInt(),
                    WHITE
                ) {
                    dial(
                        ctx,
                        cfg.contactPhone
                    )
                },
                LinearLayout.LayoutParams(
                    MATCH_PARENT,
                    WRAP_CONTENT
                ).apply {
                    topMargin = ctx.dp(8)
                }
            )
        }

        content.addView(
            box,
            LinearLayout.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT
            )
        )
    }

    // TOAST & DISPOSE
    private fun toast(t: String) {
        Toast.makeText(
            ctx,
            t,
            Toast.LENGTH_SHORT
        ).show()
    }

    fun dispose() {
        MusicPlayer.onChange = null
    }
}