package com.fpm.panel

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

/**
 * Lưu phiên kích hoạt (mã hóa bằng Android Keystore). Dữ liệu này CHỈ là bộ nhớ đệm:
 * quyền sử dụng luôn được Server xác nhận lại (/keys/status). Sửa dữ liệu máy không kéo dài được KEY.
 * Đồng hồ đếm ngược dựa trên giờ Server + SystemClock.elapsedRealtime() (không phụ thuộc đồng hồ điện thoại).
 */
class Store private constructor(private val ctx: Context) {
    companion object {
        private var inst: Store? = null
        fun get(c: Context): Store = inst ?: synchronized(this) { inst ?: Store(c.applicationContext).also { inst = it } }
        const val OFFLINE_GRACE_MS = 24L * 3600 * 1000
    }
    private val sp: SharedPreferences = try { create() } catch (e: Exception) { ctx.deleteSharedPreferences("fpm_secure"); create() }
    private fun create() = EncryptedSharedPreferences.create(
        ctx, "fpm_secure", MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)

    var session: String? get() = sp.getString("session", null); set(v) { sp.edit().apply { if (v == null) remove("session") else putString("session", v) }.apply() }
    var plan: String get() = sp.getString("plan", "") ?: ""; private set(v) { sp.edit().putString("plan", v).apply() }
    var status: String get() = sp.getString("status", "") ?: ""; private set(v) { sp.edit().putString("status", v).apply() }
    var lifetime: Boolean get() = sp.getBoolean("lifetime", false); private set(v) { sp.edit().putBoolean("lifetime", v).apply() }
    var activatedAt: Long get() = sp.getLong("activatedAt", 0); private set(v) { sp.edit().putLong("activatedAt", v).apply() }
    var expiresAt: Long get() = sp.getLong("expiresAt", 0); private set(v) { sp.edit().putLong("expiresAt", v).apply() }
    private var baseServer: Long get() = sp.getLong("baseServer", 0); set(v) { sp.edit().putLong("baseServer", v).apply() }
    private var baseElapsed: Long get() = sp.getLong("baseElapsed", 0); set(v) { sp.edit().putLong("baseElapsed", v).apply() }
    private var baseBoot: Int get() = sp.getInt("baseBoot", -2); set(v) { sp.edit().putInt("baseBoot", v).apply() }

    fun saveState(j: JSONObject, boot: Int) {
        plan = j.optString("plan"); status = j.optString("status"); lifetime = j.optBoolean("lifetime")
        activatedAt = j.optLong("activatedAt", 0); expiresAt = j.optLong("expiresAt", 0)
        baseServer = j.optLong("serverTime"); baseElapsed = SystemClock.elapsedRealtime(); baseBoot = boot
    }
    fun clearSession() { sp.edit().remove("session").remove("plan").remove("status").remove("expiresAt").remove("activatedAt").remove("baseServer").apply() }

    fun serverNow(): Long = baseServer + (SystemClock.elapsedRealtime() - baseElapsed)
    /** null = vĩnh viễn; <=0 = hết hạn */
    fun remainingMs(): Long? = if (lifetime) null else expiresAt - serverNow()
    /** Cho phép dùng tạm khi mất mạng: chưa khởi động lại máy và lần đồng bộ cuối trong 24h. */
    fun canUseOffline(c: Context): Boolean =
        session != null && baseServer > 0 && baseBoot == Session.bootCount(c) && SystemClock.elapsedRealtime() - baseElapsed in 0..OFFLINE_GRACE_MS

    fun savePanel(raw: String) { sp.edit().putString("panel", raw).apply() }
    fun panelRaw(): String? = sp.getString("panel", null)
    fun saveConfig(c: AppConfig) { sp.edit().putString("config", c.raw.toString()).apply() }
    fun config(): AppConfig = try { AppConfig(JSONObject(sp.getString("config", "{}")!!)) } catch (e: Exception) { AppConfig.default() }
}

/** Tùy chỉnh Floating Panel của người dùng (kích thước, độ trong suốt, bo góc, màu) + vị trí. */
object PanelPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("panel_prefs", Context.MODE_PRIVATE)
    fun width(c: Context, def: Int) = sp(c).getInt("width", def)
    fun opacity(c: Context, def: Float) = sp(c).getFloat("opacity", def)
    fun radius(c: Context, def: Int) = sp(c).getInt("radius", def)
    fun bg(c: Context, def: Int) = sp(c).getInt("bg", def)
    fun accent(c: Context, def: Int) = sp(c).getInt("accent", def)
    fun put(c: Context, k: String, v: Number) { sp(c).edit().apply { when (v) { is Int -> putInt(k, v); is Float -> putFloat(k, v) } }.apply() }
    fun reset(c: Context) { sp(c).edit().remove("width").remove("opacity").remove("radius").remove("bg").remove("accent").apply() }
    fun pos(c: Context) = Pair(sp(c).getInt("x", 40), sp(c).getInt("y", 220))
    fun savePos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("x", x).putInt("y", y).apply() }
    var expanded: Boolean = true
}
