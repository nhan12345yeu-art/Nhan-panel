const jwt = require('jsonwebtoken'); const cfg = require('./config'); const db = require('./db');
async function adminAuth(req, res, next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return res.status(401).json({ error: 'Chưa đăng nhập' });
  try {
    const p = jwt.verify(h.slice(7), cfg.adminJwtSecret, { algorithms: ['HS256'] });
    if (p.typ !== 'admin') throw new Error('typ');
    const r = await db.query('SELECT id,username,role FROM admins WHERE id=$1', [p.sub]);
    if (!r.rowCount) return res.status(401).json({ error: 'Tài khoản không tồn tại' });
    req.admin = r.rows[0]; next();
  } catch { res.status(401).json({ error: 'Phiên hết hạn' }); }
}
const { hashDevice, EFFECTIVE } = require('./util');
/** Xác thực người dùng Panel: session JWT + thiết bị + KEY phải còn hiệu lực (kiểm tra lại trong DB mỗi request). */
async function sessionAuth(req, res, next) {
  try {
    const h = req.headers.authorization || '';
    const deviceId = req.get('x-device-id') || (req.body && req.body.deviceId);
    if (!h.startsWith('Bearer ') || typeof deviceId !== 'string' || deviceId.length < 8 || deviceId.length > 128)
      return res.status(401).json({ ok: false, status: 'INVALID', error: 'Phiên không hợp lệ' });
    const p = jwt.verify(h.slice(7), cfg.sessionSecret, { algorithms: ['HS256'] });
    if (p.typ !== 'session') throw new Error('typ');
    const d = await db.query('SELECT id,banned FROM devices WHERE device_hash=$1', [hashDevice(deviceId)]);
    if (!d.rowCount || d.rows[0].id !== p.did || d.rows[0].banned) return res.status(403).json({ ok: false, status: 'INVALID', error: 'Thiết bị không hợp lệ' });
    const k = await db.query(`SELECT k.device_id, (${EFFECTIVE}) AS effective FROM license_keys k WHERE k.id=$1`, [p.kid]);
    if (!k.rowCount || k.rows[0].device_id !== p.did || k.rows[0].effective !== 'active')
      return res.status(403).json({ ok: false, status: (k.rows[0]?.effective || 'INVALID').toUpperCase(), error: 'KEY không còn hiệu lực' });
    req.sess = { kid: p.kid, did: p.did }; next();
  } catch { res.status(401).json({ ok: false, status: 'INVALID', error: 'Phiên hết hạn' }); }
}
const requireSuper = (req, res, next) => req.admin.role === 'superadmin' ? next() : res.status(403).json({ error: 'Cần quyền superadmin' });
module.exports = { adminAuth, requireSuper, sessionAuth };
