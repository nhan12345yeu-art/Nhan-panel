const { Pool } = require('pg'); const cfg = require('./config');
const pool = new Pool({ connectionString: cfg.databaseUrl, max: 10 });
pool.on('error', e => console.error('PG error', e.message));
module.exports = { pool, query: (t, p) => pool.query(t, p) };
