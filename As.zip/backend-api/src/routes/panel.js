// API nội dung Panel cho người dùng đã kích hoạt KEY (/api/v1/panel). Mọi quyền được kiểm tra ở Server.
const express = require('express');
const db = require('../db'); const cfg = require('../config');
const { asyncH } = require('../util');
const { sessionAuth } = require('../middleware');
const { getRev } = require('../appconfig');
const router = express.Router();
router.use(sessionAuth);

const abs = (req, u) => (!u ? '' : /^https?:\/\//i.test(u) ? u : (cfg.publicUrl || `${req.protocol}://${req.get('host')}`) + u);

router.get('/', asyncH(async (req, res) => {
  const [sec, fea, mus] = await Promise.all([
    db.query(`SELECT id,name,description,icon,kind,content,position FROM panel_sections WHERE enabled ORDER BY sort_order,id`),
    db.query(`SELECT f.id,f.section_id,f.name,f.description,f.icon,f.enabled,f.action_type,COALESCE(s.is_on,false) AS is_on
              FROM panel_features f LEFT JOIN feature_states s ON s.feature_id=f.id AND s.device_id=$1 ORDER BY f.sort_order,f.id`, [req.sess.did]),
    db.query(`SELECT id,title,url FROM music_tracks WHERE enabled ORDER BY sort_order,id`)
  ]);
  res.set('Cache-Control', 'no-store');
  res.json({
    ok: true, rev: await getRev(), serverTime: Date.now(), sections: sec.rows,
    // locked = Admin đang khóa chức năng; on chỉ có nghĩa khi không bị khóa
    features: fea.rows.map(f => ({ id: f.id, sectionId: f.section_id, name: f.name, description: f.description, icon: f.icon, locked: !f.enabled, on: f.enabled && f.is_on, hasAction: f.action_type !== 'none' })),
    tracks: mus.rows.map(t => ({ id: t.id, title: t.title, url: abs(req, t.url) }))
  });
}));

async function loadFeature(id) {
  const r = await db.query('SELECT * FROM panel_features WHERE id=$1', [id]); return r.rows[0];
}
// Người dùng bật/tắt công tắc của mình. Admin đã khóa -> Server từ chối.
router.post('/features/:id/toggle', asyncH(async (req, res) => {
  const f = await loadFeature(+req.params.id);
  if (!f) return res.status(404).json({ ok: false, error: 'Không tìm thấy chức năng' });
  if (!f.enabled) return res.status(403).json({ ok: false, locked: true, error: 'Chức năng đã bị Admin khóa' });
  const on = req.body && req.body.on === true;
  await db.query(`INSERT INTO feature_states(device_id,feature_id,is_on) VALUES($1,$2,$3)
    ON CONFLICT (device_id,feature_id) DO UPDATE SET is_on=$3, updated_at=now()`, [req.sess.did, f.id, on]);
  res.json({ ok: true, on });
}));
// Nhấn nút: chỉ khi Admin cho phép VÀ người dùng đã bật, Server mới trả hành động.
router.post('/features/:id/run', asyncH(async (req, res) => {
  const f = await loadFeature(+req.params.id);
  if (!f) return res.status(404).json({ ok: false, error: 'Không tìm thấy chức năng' });
  if (!f.enabled) return res.status(403).json({ ok: false, locked: true, error: 'Chức năng đã bị Admin khóa' });
  const s = await db.query('SELECT is_on FROM feature_states WHERE device_id=$1 AND feature_id=$2', [req.sess.did, f.id]);
  if (!s.rowCount || !s.rows[0].is_on) return res.status(403).json({ ok: false, error: 'Hãy bật chức năng trước' });
  res.json({ ok: true, action: { type: f.action_type, value: f.action_value } });
}));

module.exports = router;
