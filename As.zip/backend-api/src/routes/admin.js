// API quản trị - toàn bộ (trừ /login) yêu cầu JWT Admin, kiểm tra quyền ở backend
const express = require('express'); const bcrypt = require('bcryptjs'); const jwt = require('jsonwebtoken');
const multer = require('multer'); const crypto = require('crypto'); const path = require('path');
const rateLimit = require('express-rate-limit');
const db = require('../db'); const cfg = require('../config');
const { generateKey, hashKey, asyncH, audit, EFFECTIVE } = require('../util');
const { adminAuth, requireSuper } = require('../middleware');
const appcfg = require('../appconfig');
const router = express.Router();

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false, message: { error: 'Quá nhiều lần đăng nhập, thử lại sau 15 phút' } });
const DUMMY = bcrypt.hashSync('dummy-password-for-timing', 12);

router.post('/login', loginLimiter, asyncH(async (req, res) => {
  const { username, password } = req.body || {};
  const r = await db.query('SELECT * FROM admins WHERE username=$1', [String(username || '')]);
  const ok = await bcrypt.compare(String(password || ''), r.rowCount ? r.rows[0].password_hash : DUMMY);
  if (!r.rowCount || !ok) { return res.status(401).json({ error: 'Sai tài khoản hoặc mật khẩu' }); }
  const a = r.rows[0];
  req.admin = a; await audit(req, 'LOGIN', a.username);
  const token = jwt.sign({ typ: 'admin', sub: a.id }, cfg.adminJwtSecret, { algorithm: 'HS256', expiresIn: '8h' });
  res.json({ token, username: a.username, role: a.role });
}));

router.use(adminAuth);
router.get('/me', (req, res) => res.json(req.admin));

router.get('/stats', asyncH(async (req, res) => {
  const r = await db.query(`SELECT
    count(*)::int total,
    count(*) FILTER (WHERE (${EFFECTIVE})='unused')::int unused,
    count(*) FILTER (WHERE (${EFFECTIVE})='active')::int active,
    count(*) FILTER (WHERE (${EFFECTIVE})='expired')::int expired,
    count(*) FILTER (WHERE (${EFFECTIVE})='banned')::int banned,
    count(*) FILTER (WHERE (${EFFECTIVE})='revoked')::int revoked
    FROM license_keys k`);
  const d = await db.query(`SELECT count(DISTINCT device_id)::int n FROM license_keys WHERE device_id IS NOT NULL AND activated_at IS NOT NULL`);
  const t = await db.query('SELECT count(*)::int n FROM devices');
  const f = await db.query(`SELECT (SELECT count(*)::int FROM panel_features WHERE enabled) AS features_on, (SELECT count(*)::int FROM panel_features) AS features_total,
    (SELECT count(*)::int FROM panel_sections WHERE enabled) AS sections_on, (SELECT count(*)::int FROM music_tracks WHERE enabled) AS tracks_on`);
  res.json({ ...r.rows[0], activatedDevices: d.rows[0].n, totalDevices: t.rows[0].n, ...f.rows[0] });
}));

// ---------- KEYS ----------
function keyFilter(q) {
  const w = []; const p = [];
  if (q.status) { p.push(String(q.status).toLowerCase()); w.push(`(${EFFECTIVE})=$${p.length}`); }
  if (q.plan && cfg.plans.hasOwnProperty(q.plan)) { p.push(q.plan); w.push(`k.plan=$${p.length}`); }
  if (q.q) {
    const s = String(q.q).trim(); p.push(hashKey(s)); const a = p.length; p.push('%' + s.replace(/[%_]/g, '') + '%'); const b = p.length;
    w.push(`(k.key_hash=$${a} OR k.key_hint ILIKE $${b} OR k.note ILIKE $${b})`);
  }
  return { where: w.length ? 'WHERE ' + w.join(' AND ') : '', p };
}
const KEY_COLS = `k.id,k.key_hint,k.plan,k.note,k.created_at,k.activated_at,k.expires_at,k.status AS raw_status,(${EFFECTIVE}) AS status,
  d.id AS device_id, d.model AS device_model, a.username AS created_by_name`;
const KEY_FROM = `FROM license_keys k LEFT JOIN devices d ON d.id=k.device_id LEFT JOIN admins a ON a.id=k.created_by`;

router.get('/keys', asyncH(async (req, res) => {
  const { where, p } = keyFilter(req.query);
  const limit = Math.min(200, Math.max(1, +req.query.limit || 50)); const page = Math.max(1, +req.query.page || 1);
  const total = (await db.query(`SELECT count(*)::int n ${KEY_FROM} ${where}`, p)).rows[0].n;
  const r = await db.query(`SELECT ${KEY_COLS} ${KEY_FROM} ${where} ORDER BY k.id DESC LIMIT ${limit} OFFSET ${(page - 1) * limit}`, p);
  res.json({ total, page, limit, items: r.rows, serverTime: Date.now() });
}));

router.get('/keys/export', asyncH(async (req, res) => {
  const { where, p } = keyFilter(req.query);
  const r = await db.query(`SELECT ${KEY_COLS} ${KEY_FROM} ${where} ORDER BY k.id DESC LIMIT 50000`, p);
  const esc = (v) => { v = v == null ? '' : (v instanceof Date ? v.toISOString() : String(v)); return /^[=+\-@]/.test(v) ? "'" + v : v; };
  const q = (v) => '"' + esc(v).replace(/"/g, '""') + '"';
  const lines = ['id,key_hint,plan,status,created_at,activated_at,expires_at,device,note'];
  for (const x of r.rows) lines.push([x.id, '****' + x.key_hint, x.plan, x.status, x.created_at, x.activated_at, x.expires_at, x.device_model, x.note].map(q).join(','));
  await audit(req, 'EXPORT_KEYS', null, `${r.rowCount} keys`);
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="keys.csv"' }).send('\uFEFF' + lines.join('\n'));
}));

router.post('/keys', asyncH(async (req, res) => {
  const plan = String(req.body.plan || ''); const count = Math.floor(+req.body.count || 1);
  if (!cfg.plans.hasOwnProperty(plan)) return res.status(400).json({ error: 'Loại KEY không hợp lệ' });
  if (count < 1 || count > 500) return res.status(400).json({ error: 'Số lượng 1-500' });
  const note = String(req.body.note || '').slice(0, 200) || null;
  const created = [];
  while (created.length < count) {
    const key = generateKey();
    const r = await db.query(`INSERT INTO license_keys(key_hash,key_hint,plan,duration_seconds,note,created_by) VALUES($1,$2,$3,$4,$5,$6)
      ON CONFLICT (key_hash) DO NOTHING RETURNING id`, [hashKey(key), key.slice(-4), plan, cfg.plans[plan], note, req.admin.id]);
    if (r.rowCount) created.push({ id: r.rows[0].id, key, plan });
  }
  await audit(req, 'CREATE_KEYS', plan, `${count} keys`);
  res.status(201).json({ keys: created }); // KEY gốc chỉ trả về một lần duy nhất
}));

async function keyAction(req, res, action, sql, params = []) {
  const id = +req.params.id;
  const r = await db.query(sql, [id, ...params]);
  if (!r.rowCount) return res.status(404).json({ error: 'Không tìm thấy KEY hoặc thao tác không hợp lệ' });
  await audit(req, action, 'key#' + id); res.json({ ok: true });
}
router.post('/keys/:id/ban', asyncH((q, s) => keyAction(q, s, 'BAN_KEY', `UPDATE license_keys SET status='banned' WHERE id=$1 AND status IN ('unused','active')`)));
router.post('/keys/:id/unban', asyncH((q, s) => keyAction(q, s, 'UNBAN_KEY', `UPDATE license_keys SET status=CASE WHEN activated_at IS NULL THEN 'unused' ELSE 'active' END WHERE id=$1 AND status='banned'`)));
router.post('/keys/:id/revoke', asyncH((q, s) => keyAction(q, s, 'REVOKE_KEY', `UPDATE license_keys SET status='revoked' WHERE id=$1 AND status<>'revoked'`)));
router.post('/keys/:id/reset-device', asyncH((q, s) => keyAction(q, s, 'RESET_DEVICE', `UPDATE license_keys SET device_id=NULL WHERE id=$1`)));
router.post('/keys/:id/extend', asyncH(async (req, res) => { // GIA HẠN KEY
  const plan = String(req.body.plan || ''); const secs = cfg.plans[plan];
  if (!secs) return res.status(400).json({ error: 'Chọn loại gia hạn (không áp dụng cho LIFETIME)' });
  const r = await db.query(`UPDATE license_keys SET
      duration_seconds = CASE WHEN activated_at IS NULL THEN duration_seconds + $2 ELSE duration_seconds END,
      expires_at = CASE WHEN activated_at IS NOT NULL THEN GREATEST(expires_at, now()) + make_interval(secs => $2) ELSE expires_at END
    WHERE id=$1 AND duration_seconds IS NOT NULL AND status IN ('unused','active')`, [+req.params.id, secs]);
  if (!r.rowCount) return res.status(400).json({ error: 'KEY không thể gia hạn (vĩnh viễn, bị khóa hoặc đã thu hồi)' });
  await audit(req, 'EXTEND_KEY', 'key#' + req.params.id, plan); res.json({ ok: true });
}));
router.delete('/keys/:id', asyncH((q, s) => keyAction(q, s, 'DELETE_KEY', `DELETE FROM license_keys WHERE id=$1`)));

// ---------- DEVICES ----------
router.get('/devices', asyncH(async (req, res) => {
  const s = String(req.query.q || '').trim();
  const r = await db.query(`SELECT d.id,d.model,d.banned,d.first_seen,d.last_seen,d.last_ip,
      (SELECT json_agg(json_build_object('id',k.id,'hint',k.key_hint,'plan',k.plan,'status',(${EFFECTIVE}),'expires_at',k.expires_at))
         FROM license_keys k WHERE k.device_id=d.id) AS keys
    FROM devices d WHERE ($1='' OR d.model ILIKE '%'||$1||'%' OR d.last_ip ILIKE '%'||$1||'%') ORDER BY d.last_seen DESC LIMIT 500`, [s.replace(/[%_]/g, '')]);
  res.json({ items: r.rows });
}));
router.get('/devices/:id/history', asyncH(async (req, res) => {
  const r = await db.query(`SELECT a.id,a.event,a.ip,a.created_at,k.key_hint,k.plan FROM activations a LEFT JOIN license_keys k ON k.id=a.key_id WHERE a.device_id=$1 ORDER BY a.id DESC LIMIT 200`, [+req.params.id]);
  res.json({ items: r.rows });
}));
router.post('/devices/:id/ban', asyncH(async (req, res) => {
  const r = await db.query('UPDATE devices SET banned=true WHERE id=$1', [+req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Không tìm thấy' });
  await audit(req, 'BAN_DEVICE', 'device#' + req.params.id); res.json({ ok: true });
}));
router.post('/devices/:id/unban', asyncH(async (req, res) => {
  await db.query('UPDATE devices SET banned=false WHERE id=$1', [+req.params.id]);
  await audit(req, 'UNBAN_DEVICE', 'device#' + req.params.id); res.json({ ok: true });
}));
router.post('/devices/:id/reset', asyncH(async (req, res) => {
  await db.query('UPDATE license_keys SET device_id=NULL WHERE device_id=$1', [+req.params.id]);
  await audit(req, 'RESET_DEVICE', 'device#' + req.params.id); res.json({ ok: true });
}));

// ---------- APP CONFIG ----------
router.get('/config', asyncH(async (req, res) => res.json(await appcfg.getRaw())));
router.put('/config', asyncH(async (req, res) => {
  const cur = await appcfg.getRaw(); const next = appcfg.sanitize(req.body, cur);
  await appcfg.save(next); await appcfg.bumpRev(); await audit(req, 'SAVE_CONFIG', null, 'v' + next.version); res.json(next);
}));
router.post('/config/sync', asyncH(async (req, res) => { // ĐỒNG BỘ NGAY: tăng version để mọi app tải lại
  const cur = await appcfg.getRaw(); cur.version = (cur.version || 1) + 1;
  await appcfg.save(cur); await appcfg.bumpRev(); await audit(req, 'SYNC_CONFIG', null, 'v' + cur.version); res.json({ version: cur.version });
}));

const MIME = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif' };
const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, '..', '..', 'uploads'),
    filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + MIME[file.mimetype])
  }),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => MIME[file.mimetype] ? cb(null, true) : cb(new Error('Chỉ nhận PNG/JPG/WEBP/GIF'))
});
router.post('/upload', upload.single('file'), asyncH(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Thiếu file' });
  await audit(req, 'UPLOAD', req.file.filename); res.json({ url: '/uploads/' + req.file.filename });
}));

const AUDIO = { 'audio/mpeg': '.mp3', 'audio/mp4': '.m4a', 'audio/x-m4a': '.m4a', 'audio/ogg': '.ogg', 'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/aac': '.aac' };
const uploadAudio = multer({
  storage: multer.diskStorage({ destination: path.join(__dirname, '..', '..', 'uploads'), filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + AUDIO[file.mimetype]) }),
  limits: { fileSize: 25 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => AUDIO[file.mimetype] ? cb(null, true) : cb(new Error('Chỉ nhận MP3/M4A/OGG/WAV/AAC'))
});
router.post('/upload-audio', uploadAudio.single('file'), asyncH(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Thiếu file' });
  await audit(req, 'UPLOAD_AUDIO', req.file.filename); res.json({ url: '/uploads/' + req.file.filename });
}));
router.use('/hub', require('./hub'));

// ---------- LOGS & ADMINS ----------
router.get('/logs', asyncH(async (req, res) => {
  const r = await db.query('SELECT id,admin_name,action,target,detail,ip,created_at FROM audit_logs ORDER BY id DESC LIMIT 300');
  res.json({ items: r.rows });
}));
router.get('/admins', requireSuper, asyncH(async (req, res) => {
  res.json({ items: (await db.query('SELECT id,username,role,created_at FROM admins ORDER BY id')).rows });
}));
router.post('/admins', requireSuper, asyncH(async (req, res) => {
  const { username, password, role } = req.body || {};
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username || '') || String(password || '').length < 10) return res.status(400).json({ error: 'Username 3-32 ký tự, mật khẩu >= 10 ký tự' });
  const r = await db.query('INSERT INTO admins(username,password_hash,role) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING id',
    [username, await bcrypt.hash(password, 12), role === 'superadmin' ? 'superadmin' : 'admin']);
  if (!r.rowCount) return res.status(409).json({ error: 'Username đã tồn tại' });
  await audit(req, 'CREATE_ADMIN', username); res.status(201).json({ ok: true });
}));
router.delete('/admins/:id', requireSuper, asyncH(async (req, res) => {
  if (+req.params.id === req.admin.id) return res.status(400).json({ error: 'Không thể tự xóa mình' });
  await db.query('DELETE FROM admins WHERE id=$1', [+req.params.id]); await audit(req, 'DELETE_ADMIN', 'admin#' + req.params.id); res.json({ ok: true });
}));

module.exports = router;
