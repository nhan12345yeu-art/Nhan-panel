// API công khai cho Android App
const express = require('express'); const jwt = require('jsonwebtoken');
const db = require('../db'); const cfg = require('../config');
const { hashKey, hashDevice, normKey, asyncH, clientIp, EFFECTIVE } = require('../util');
const { loadAppConfig } = require('../appconfig');
const router = express.Router();

const SESSION_TTL = '30d';
const signSession = (kid, did) => jwt.sign({ typ: 'session', kid, did }, cfg.sessionSecret, { algorithm: 'HS256', expiresIn: SESSION_TTL });

function payload(k, token) {
  const now = Date.now();
  const lifetime = k.activated_at && !k.expires_at;
  return {
    ok: true, status: k.effective.toUpperCase(), plan: k.plan, lifetime: !!lifetime,
    activatedAt: k.activated_at ? new Date(k.activated_at).getTime() : null,
    expiresAt: k.expires_at ? new Date(k.expires_at).getTime() : null,
    serverTime: now, ...(token ? { session: token } : {})
  };
}
async function failedCount(ip, dev) {
  const r = await db.query(`SELECT count(*)::int c FROM login_attempts WHERE success=false AND created_at > now() - interval '15 minutes' AND (ip=$1 OR device_hash=$2)`, [ip, dev]);
  return r.rows[0].c;
}
const logAttempt = (ip, dev, ok) => db.query('INSERT INTO login_attempts(ip,device_hash,success) VALUES($1,$2,$3)', [ip, dev, ok]);
async function upsertDevice(dh, model, ip) {
  const r = await db.query(`INSERT INTO devices(device_hash,model,last_ip) VALUES($1,$2,$3)
    ON CONFLICT (device_hash) DO UPDATE SET last_seen=now(), last_ip=EXCLUDED.last_ip, model=COALESCE(EXCLUDED.model, devices.model)
    RETURNING id, banned`, [dh, model || null, ip]);
  return r.rows[0];
}
const validDevice = (d) => typeof d === 'string' && d.length >= 8 && d.length <= 128;

router.get('/time', (req, res) => res.json({ serverTime: Date.now() }));

router.get('/config', asyncH(async (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(await loadAppConfig(req));
}));

router.post('/keys/activate', asyncH(async (req, res) => {
  const ip = clientIp(req); const { deviceId, model } = req.body || {};
  if (!validDevice(deviceId)) return res.status(400).json({ ok: false, error: 'Thiếu mã thiết bị' });
  const key = normKey(req.body.key);
  if (key.length < 16 || key.length > 40) return res.status(400).json({ ok: false, error: 'KEY không hợp lệ' });
  const dh = hashDevice(deviceId);

  if (await failedCount(ip, dh) >= cfg.maxFailed)
    return res.status(429).json({ ok: false, error: 'Nhập sai quá nhiều lần. Thử lại sau 15 phút.' });

  const dev = await upsertDevice(dh, String(model || '').slice(0, 80), ip);
  if (dev.banned) { await logAttempt(ip, dh, false); return res.status(403).json({ ok: false, error: 'Thiết bị đã bị khóa' }); }

  const kh = hashKey(key);
  let r = await db.query(`SELECT k.*, (${EFFECTIVE}) AS effective FROM license_keys k WHERE key_hash=$1`, [kh]);
  if (!r.rowCount) { await logAttempt(ip, dh, false); return res.status(404).json({ ok: false, error: 'KEY không hợp lệ' }); }
  let k = r.rows[0];

  if (k.status === 'banned') { await logAttempt(ip, dh, false); return res.status(403).json({ ok: false, error: 'KEY đã bị khóa' }); }
  if (k.status === 'revoked') { await logAttempt(ip, dh, false); return res.status(403).json({ ok: false, error: 'KEY đã bị thu hồi' }); }
  if (k.effective === 'expired') { await logAttempt(ip, dh, false); return res.status(403).json({ ok: false, error: 'KEY đã hết hạn', status: 'EXPIRED' }); }

  if (k.status === 'unused') {
    // Kích hoạt nguyên tử: chỉ một request thắng
    const u = await db.query(`UPDATE license_keys SET status='active', activated_at=now(),
        expires_at = CASE WHEN duration_seconds IS NULL THEN NULL ELSE now() + make_interval(secs => duration_seconds) END,
        device_id=$2 WHERE id=$1 AND status='unused' RETURNING id`, [k.id, dev.id]);
    await db.query('INSERT INTO activations(key_id,device_id,event,ip) VALUES($1,$2,$3,$4)', [k.id, dev.id, u.rowCount ? 'activate' : 'denied', ip]);
    r = await db.query(`SELECT k.*, (${EFFECTIVE}) AS effective FROM license_keys k WHERE id=$1`, [k.id]); k = r.rows[0];
  }
  if (k.device_id == null && k.status === 'active') { // Admin đã reset thiết bị -> gắn thiết bị mới
    await db.query('UPDATE license_keys SET device_id=$2 WHERE id=$1 AND device_id IS NULL', [k.id, dev.id]);
    await db.query('INSERT INTO activations(key_id,device_id,event,ip) VALUES($1,$2,$3,$4)', [k.id, dev.id, 'rebind', ip]);
    k.device_id = dev.id;
  }
  if (k.device_id !== dev.id) {
    await logAttempt(ip, dh, false);
    await db.query('INSERT INTO activations(key_id,device_id,event,ip) VALUES($1,$2,$3,$4)', [k.id, dev.id, 'denied', ip]);
    return res.status(403).json({ ok: false, error: 'KEY đã được dùng trên thiết bị khác' });
  }
  await logAttempt(ip, dh, true);
  res.json(payload(k, signSession(k.id, dev.id)));
}));

// Kiểm tra / đồng bộ thời hạn bằng session token
router.post('/keys/status', asyncH(async (req, res) => {
  const h = req.headers.authorization || '';
  const deviceId = req.body && req.body.deviceId;
  if (!h.startsWith('Bearer ') || !validDevice(deviceId)) return res.status(401).json({ ok: false, status: 'INVALID', error: 'Phiên không hợp lệ' });
  let p;
  try { p = jwt.verify(h.slice(7), cfg.sessionSecret, { algorithms: ['HS256'] }); if (p.typ !== 'session') throw 0; }
  catch { return res.status(401).json({ ok: false, status: 'INVALID', error: 'Phiên hết hạn, vui lòng nhập lại KEY' }); }
  const dh = hashDevice(deviceId);
  const d = await db.query('SELECT id,banned FROM devices WHERE device_hash=$1', [dh]);
  if (!d.rowCount || d.rows[0].id !== p.did) return res.status(403).json({ ok: false, status: 'INVALID', error: 'Thiết bị không khớp' });
  if (d.rows[0].banned) return res.status(403).json({ ok: false, status: 'BANNED', error: 'Thiết bị đã bị khóa' });
  const r = await db.query(`SELECT k.*, (${EFFECTIVE}) AS effective FROM license_keys k WHERE id=$1`, [p.kid]);
  if (!r.rowCount) return res.status(403).json({ ok: false, status: 'INVALID', error: 'KEY không tồn tại' });
  const k = r.rows[0];
  if (k.device_id !== p.did) return res.status(403).json({ ok: false, status: 'INVALID', error: 'KEY không còn gắn với thiết bị này' });
  await db.query('UPDATE devices SET last_seen=now(), last_ip=$2 WHERE id=$1', [p.did, clientIp(req)]);
  if (k.effective !== 'active') {
    const msg = { expired: 'KEY đã hết hạn', banned: 'KEY đã bị khóa', revoked: 'KEY đã bị thu hồi' }[k.effective] || 'KEY không hợp lệ';
    return res.status(403).json({ ...payload(k), ok: false, error: msg });
  }
  res.json(payload(k));
}));

module.exports = router;
