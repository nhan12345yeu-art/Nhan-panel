// Admin Hub: CRUD chức năng / danh mục / nhạc / box share. Mọi thay đổi tăng "rev" để Panel tự đồng bộ.
const express = require('express');
const db = require('../db'); const { asyncH, audit } = require('../util'); const { bumpRev } = require('../appconfig');
const router = express.Router();
const str = (s, m) => String(s ?? '').trim().slice(0, m);
const bool = (v) => v === true || v === 'true';
const httpsOnly = (s) => /^https:\/\/\S+$/i.test(s);
const urlOrUpload = (s) => s.startsWith('/uploads/') || httpsOnly(s);

const entities = {
  features: {
    table: 'panel_features',
    clean(b) {
      const name = str(b.name, 60); if (!name) return { error: 'Thiếu tên chức năng' };
      const type = ['none', 'link', 'toast', 'call'].includes(b.action_type) ? b.action_type : 'none';
      let val = str(b.action_value, 300);
      if (type === 'none') val = '';
      if (type === 'link' && !httpsOnly(val)) return { error: 'Liên kết phải bắt đầu bằng https://' };
      if (type === 'call') { val = val.replace(/[^0-9+]/g, ''); if (!/^\+?[0-9]{6,15}$/.test(val)) return { error: 'Số điện thoại không hợp lệ' }; }
      if (type === 'toast' && !val) return { error: 'Thiếu nội dung thông báo' };
      const sid = b.section_id === '' || b.section_id == null ? null : parseInt(b.section_id, 10);
      return { data: { section_id: Number.isInteger(sid) ? sid : null, name, description: str(b.description, 200), icon: str(b.icon, 8) || '⚡', enabled: bool(b.enabled), action_type: type, action_value: val } };
    }
  },
  sections: {
    table: 'panel_sections',
    clean(b) {
      const name = str(b.name, 60); if (!name) return { error: 'Thiếu tên danh mục' };
      return { data: { name, description: str(b.description, 200), icon: str(b.icon, 8) || '📁', kind: ['features', 'music', 'contact', 'text'].includes(b.kind) ? b.kind : 'text',
        content: str(b.content, 3000), position: b.position === 'bottom' ? 'bottom' : 'top', enabled: bool(b.enabled) } };
    }
  },
  music: {
    table: 'music_tracks',
    clean(b) {
      const title = str(b.title, 100), url = str(b.url, 500);
      if (!title) return { error: 'Thiếu tên bài hát' };
      if (!urlOrUpload(url)) return { error: 'Đường dẫn nhạc phải là https:// hoặc file đã tải lên' };
      return { data: { title, url, enabled: bool(b.enabled) } };
    }
  },
  share: {
    table: 'share_items',
    clean(b) {
      const title = str(b.title, 80); if (!title) return { error: 'Thiếu tiêu đề' };
      const link = str(b.link, 300); if (link && !httpsOnly(link)) return { error: 'Liên kết phải bắt đầu bằng https://' };
      return { data: { title, content: str(b.content, 500), link, enabled: bool(b.enabled) } };
    }
  }
};

for (const [name, ent] of Object.entries(entities)) {
  const T = ent.table;
  router.get('/' + name, asyncH(async (req, res) => res.json({ items: (await db.query(`SELECT * FROM ${T} ORDER BY sort_order,id`)).rows })));
  router.post('/' + name + '/reorder', asyncH(async (req, res) => {
    const ids = (req.body.ids || []).map(Number).filter(Number.isInteger);
    if (!ids.length) return res.status(400).json({ error: 'Thiếu danh sách' });
    await db.query(`UPDATE ${T} t SET sort_order=v.ord FROM (SELECT unnest($1::int[]) AS id, generate_series(1, array_length($1::int[],1)) AS ord) v WHERE t.id=v.id`, [ids]);
    await bumpRev(); await audit(req, 'REORDER_' + name.toUpperCase()); res.json({ ok: true });
  }));
  router.post('/' + name, asyncH(async (req, res) => {
    const c = ent.clean(req.body || {}); if (c.error) return res.status(400).json({ error: c.error });
    const keys = Object.keys(c.data);
    try {
      const r = await db.query(`INSERT INTO ${T}(${keys.join(',')},sort_order) VALUES(${keys.map((_, i) => '$' + (i + 1)).join(',')},(SELECT COALESCE(MAX(sort_order),0)+1 FROM ${T})) RETURNING *`, keys.map(k => c.data[k]));
      await bumpRev(); await audit(req, 'ADD_' + name.toUpperCase(), '#' + r.rows[0].id, c.data.name || c.data.title); res.status(201).json(r.rows[0]);
    } catch (e) { if (e.code === '23503') return res.status(400).json({ error: 'Danh mục không tồn tại' }); throw e; }
  }));
  router.put('/' + name + '/:id', asyncH(async (req, res) => {
    const cur = await db.query(`SELECT * FROM ${T} WHERE id=$1`, [+req.params.id]);
    if (!cur.rowCount) return res.status(404).json({ error: 'Không tìm thấy' });
    const c = ent.clean({ ...cur.rows[0], ...(req.body || {}) }); if (c.error) return res.status(400).json({ error: c.error });
    const keys = Object.keys(c.data);
    try {
      const r = await db.query(`UPDATE ${T} SET ${keys.map((k, i) => `${k}=$${i + 1}`).join(',')} WHERE id=$${keys.length + 1} RETURNING *`, [...keys.map(k => c.data[k]), +req.params.id]);
      await bumpRev(); await audit(req, 'EDIT_' + name.toUpperCase(), '#' + req.params.id, c.data.name || c.data.title); res.json(r.rows[0]);
    } catch (e) { if (e.code === '23503') return res.status(400).json({ error: 'Danh mục không tồn tại' }); throw e; }
  }));
  router.delete('/' + name + '/:id', asyncH(async (req, res) => {
    await db.query(`DELETE FROM ${T} WHERE id=$1`, [+req.params.id]);
    await bumpRev(); await audit(req, 'DELETE_' + name.toUpperCase(), '#' + req.params.id); res.json({ ok: true });
  }));
}
module.exports = router;
