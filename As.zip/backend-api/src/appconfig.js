const db = require('./db'); const cfg = require('./config');
const isObj = (o) => o && typeof o === 'object' && !Array.isArray(o);
function merge(base, over) {
  const out = { ...base };
  for (const k of Object.keys(base)) {
    if (over && k in over) out[k] = isObj(base[k]) && isObj(over[k]) ? merge(base[k], over[k]) : over[k];
  }
  return out;
}
async function getRaw() {
  const r = await db.query("SELECT value FROM settings WHERE name='app_config'");
  return merge(cfg.defaultAppConfig, r.rowCount ? r.rows[0].value : {});
}
function absolutize(req, url) {
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  const base = cfg.publicUrl || `${req.protocol}://${req.get('host')}`;
  return base + url;
}
async function getRev() {
  const r = await db.query("SELECT value FROM settings WHERE name='content_rev'");
  return r.rowCount ? Number(r.rows[0].value) : 1;
}
async function bumpRev() {
  await db.query(`INSERT INTO settings(name,value) VALUES('content_rev','2') ON CONFLICT (name) DO UPDATE SET value=to_jsonb((settings.value#>>'{}')::bigint+1), updated_at=now()`);
}
async function loadAppConfig(req) {
  const c = await getRaw();
  c.rev = await getRev();
  c.panelBackgroundUrl = absolutize(req, c.panelBackgroundUrl);
  c.adminProfile.avatarUrl = absolutize(req, c.adminProfile.avatarUrl);
  c.shareItems = (await db.query('SELECT id,title,content,link FROM share_items WHERE enabled ORDER BY sort_order,id')).rows;
  c.logoUrl = absolutize(req, c.logoUrl); c.panelLogoUrl = absolutize(req, c.panelLogoUrl);
  c.backgroundUrl = absolutize(req, c.backgroundUrl); c.banner.url = absolutize(req, c.banner.url);
  c.serverTime = Date.now();
  return c;
}
const hex = /^#[0-9a-fA-F]{6}$/; const clampNum = (n, a, b, d) => { n = Number(n); return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : d; };
const str = (s, max) => String(s ?? '').slice(0, max);
const link = (s) => { s = String(s ?? '').trim().slice(0, 300); return (s === '' || /^https:\/\/\S+$/i.test(s) || /^tel:\+?[0-9]{6,15}$/.test(s)) ? s : ''; };
const url = (s) => { s = String(s ?? '').slice(0, 500); return (s === '' || s.startsWith('/uploads/') || /^https:\/\//i.test(s)) ? s : ''; };
function sanitize(inp, cur) {
  const c = merge(cfg.defaultAppConfig, inp || {});
  const d = cfg.defaultAppConfig;
  const out = {
    version: (cur.version || 1) + 1,
    appName: str(c.appName, 60), title: str(c.title, 100), description: str(c.description, 500), announcement: str(c.announcement, 500),
    banner: { enabled: !!c.banner.enabled, url: url(c.banner.url) },
    logoUrl: url(c.logoUrl), panelLogoUrl: url(c.panelLogoUrl), backgroundUrl: url(c.backgroundUrl),
    colors: {}, login: {
      title: str(c.login.title, 80), description: str(c.login.description, 300),
      placeholder: str(c.login.placeholder, 60), buttonText: str(c.login.buttonText, 30)
    },
    expiredMessage: str(c.expiredMessage, 300), toggles: {},
    panelIntro: str(c.panelIntro, 500), panelBackgroundUrl: url(c.panelBackgroundUrl),
    adminProfile: { name: str(c.adminProfile.name, 60), avatarUrl: url(c.adminProfile.avatarUrl), bio: str(c.adminProfile.bio, 400),
      links: (Array.isArray(c.adminProfile.links) ? c.adminProfile.links : []).slice(0, 6).map(l => ({ label: str(l && l.label, 30), url: link(l && l.url) })).filter(l => l.label && l.url) },
    contact: { phone: String(c.contact.phone || '').replace(/[^0-9+]/g, '').slice(0, 16), zaloUrl: link(c.contact.zaloUrl), message: str(c.contact.message, 300) },
    shareBox: { enabled: !!c.shareBox.enabled, title: str(c.shareBox.title, 60), description: str(c.shareBox.description, 300) },
    panel: { opacity: clampNum(c.panel.opacity, 0.3, 1, d.panel.opacity), cornerRadius: clampNum(c.panel.cornerRadius, 0, 40, d.panel.cornerRadius), width: clampNum(c.panel.width, 180, 420, d.panel.width), title: str(c.panel.title, 30) }
  };
  for (const k of Object.keys(d.colors)) out.colors[k] = hex.test(c.colors[k]) ? c.colors[k] : d.colors[k];
  for (const k of Object.keys(d.toggles)) out.toggles[k] = !!c.toggles[k];
  return out;
}
async function save(value) {
  await db.query(`INSERT INTO settings(name,value) VALUES('app_config',$1) ON CONFLICT (name) DO UPDATE SET value=$1, updated_at=now()`, [value]);
}
module.exports = { getRaw, loadAppConfig, sanitize, save, getRev, bumpRev };
