require('dotenv').config();
const need = (k) => { if (!process.env[k] || process.env[k].length < 32) { console.error(`Thiếu/ngắn biến môi trường ${k} (>=32 ký tự). Xem .env.example`); process.exit(1); } return process.env[k]; };
module.exports = {
  port: +process.env.PORT || 3000,
  databaseUrl: process.env.DATABASE_URL,
  adminJwtSecret: need('ADMIN_JWT_SECRET'),
  sessionSecret: need('SESSION_SECRET'),
  keyPepper: need('KEY_PEPPER'),
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
  trustProxy: process.env.TRUST_PROXY === 'true',
  // Dashboard chạy ở website riêng: chỉ các origin này được gọi /api/admin từ trình duyệt.
  // CORS_ORIGIN là tên biến cũ, vẫn được chấp nhận để không phá cấu hình hiện có.
  adminOrigins: (process.env.ADMIN_ORIGINS || process.env.CORS_ORIGIN || '').split(',').map(x => x.trim().replace(/\/$/, '')).filter(Boolean),
  adminApiEnabled: process.env.ADMIN_API_ENABLED !== 'false',
  adminIpAllowlist: (process.env.ADMIN_IP_ALLOWLIST || '').split(',').map(x => x.trim()).filter(Boolean),
  maxFailed: +process.env.MAX_FAILED_ATTEMPTS || 8,
  plans: { '1HOUR': 3600, '1DAY': 86400, '7DAY': 604800, '1MONTH': 2592000, '1YEAR': 31536000, 'LIFETIME': null },
  defaultAppConfig: {
    version: 1,
    appName: 'FLOATING PANEL PRO MAX',
    title: 'Chào mừng',
    description: 'Nhập KEY để kích hoạt ứng dụng.',
    announcement: '',
    banner: { enabled: false, url: '' },
    logoUrl: '', panelLogoUrl: '', backgroundUrl: '',
    colors: { primary: '#00E5FF', button: '#7C4DFF', text: '#FFFFFF', background: '#0B0F1A', surface: '#141A2B' },
    login: { title: 'KÍCH HOẠT KEY', description: 'Nhập KEY được cấp để sử dụng.', placeholder: 'XXXXX-XXXXX-XXXXX-XXXXX', buttonText: 'KÍCH HOẠT' },
    expiredMessage: 'KEY của bạn đã hết hạn. Vui lòng nhập KEY mới.',
    toggles: { showBanner: true, showAnnouncement: true, showSettingsButton: true, showServerStatus: true, showCountdown: true },
    panel: { opacity: 0.92, cornerRadius: 18, width: 300, title: 'PANEL' },
    panelIntro: 'Chào mừng bạn đến với Panel.',
    panelBackgroundUrl: '',
    adminProfile: { name: '', avatarUrl: '', bio: '', links: [] },
    contact: { phone: '0357924374', zaloUrl: '', message: 'Nếu gặp lỗi hoặc cần hỗ trợ, vui lòng liên hệ Admin.' },
    shareBox: { enabled: true, title: 'BOX SHARE KEY FREE', description: '' }
  }
};
