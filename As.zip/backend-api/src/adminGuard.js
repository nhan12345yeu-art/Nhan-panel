// Lớp bảo vệ cho /api/admin (đứng TRƯỚC đăng nhập và mọi route quản trị).
// Quyền admin chỉ dựa vào JWT admin phía server (middleware.adminAuth); không bao giờ tin dữ liệu từ app Android.
function normIp(ip) { return String(ip || '').replace(/^::ffff:/, ''); }
function createAdminGuard({ enabled, allowlist }) {
  const allow = (allowlist || []).map(normIp);
  return function adminGuard(req, res, next) {
    if (!enabled) return res.status(404).json({ error: 'Not found' });          // tắt hẳn API quản trị trên instance này
    if (allow.length && !allow.includes(normIp(req.ip || (req.socket && req.socket.remoteAddress)))) {
      return res.status(404).json({ error: 'Not found' });                      // không lộ sự tồn tại của API admin
    }
    next();
  };
}
module.exports = { createAdminGuard, normIp };
