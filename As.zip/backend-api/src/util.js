const crypto = require('crypto'); const cfg = require('./config'); const db = require('./db');
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function generateKey() {
  const b = crypto.randomBytes(20); let s = '';
  for (let i = 0; i < 20; i++) s += ALPHA[b[i] % ALPHA.length];
  return 'FPPM-' + s.match(/.{5}/g).join('-');
}
const normKey = (k) => String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
// Hash trên dạng chuẩn hóa (bỏ '-', chữ hoa) để nhập thiếu dấu gạch vẫn đúng
const hashKey = (k) => crypto.createHmac('sha256', cfg.keyPepper).update(normKey(k)).digest('hex');
const hashDevice = (d) => crypto.createHmac('sha256', cfg.keyPepper).update('dev:' + d).digest('hex');
const asyncH = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const clientIp = (req) => req.ip || req.socket.remoteAddress || '';
async function audit(req, action, target, detail) {
  try {
    await db.query('INSERT INTO audit_logs(admin_id,admin_name,action,target,detail,ip) VALUES($1,$2,$3,$4,$5,$6)',
      [req.admin?.id || null, req.admin?.username || null, action, target || null, detail || null, clientIp(req)]);
  } catch (e) { console.error('audit', e.message); }
}
const EFFECTIVE = `CASE WHEN k.status='active' AND k.expires_at IS NOT NULL AND k.expires_at < now() THEN 'expired' ELSE k.status END`;
module.exports = { generateKey, hashKey, normKey, hashDevice, asyncH, clientIp, audit, EFFECTIVE };
