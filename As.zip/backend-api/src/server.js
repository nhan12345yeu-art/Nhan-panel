const express = require('express'); const helmet = require('helmet'); const cors = require('cors');
const rateLimit = require('express-rate-limit'); const path = require('path');
const cfg = require('./config'); const { createAdminGuard } = require('./adminGuard');

const app = express();
if (cfg.trustProxy) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], imgSrc: ["'self'", 'data:', 'blob:'], styleSrc: ["'self'"], scriptSrc: ["'self'"], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"] } },
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
// /api/v1 (app Android) KHÔNG bật CORS: app native không cần, và trang web lạ không được gọi API người dùng.
// /api/admin: chỉ cho phép đúng origin của website Admin Dashboard (ADMIN_ORIGINS).
const adminGuard = createAdminGuard({ enabled: cfg.adminApiEnabled, allowlist: cfg.adminIpAllowlist });
app.use('/api/admin', adminGuard);
if (cfg.adminOrigins.length) app.use('/api/admin', cors({ origin: cfg.adminOrigins, methods: ['GET', 'POST', 'PUT', 'DELETE'], allowedHeaders: ['Authorization', 'Content-Type'], maxAge: 600 }));
app.use(express.json({ limit: '100kb' }));

app.use('/api/v1', rateLimit({ windowMs: 60 * 1000, max: 240, standardHeaders: true, legacyHeaders: false }), require('./routes/public'));
app.use('/api/v1/panel', rateLimit({ windowMs: 60 * 1000, max: 240, standardHeaders: true, legacyHeaders: false }), require('./routes/panel'));
app.use('/api/admin', rateLimit({ windowMs: 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }), require('./routes/admin'));

app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads'), { maxAge: '1h', index: false, setHeaders: r => r.setHeader('X-Content-Type-Options', 'nosniff') }));
// Backend không còn phục vụ giao diện Admin: Dashboard là website riêng (thư mục admin-dashboard).
app.get('/health', (req, res) => res.json({ ok: true, serverTime: Date.now() }));

app.use((err, req, res, next) => {
  if (err && err.message && /PNG|MP3|Multer|File too large/i.test(err.message + err.name)) return res.status(400).json({ error: err.message });
  console.error(err); res.status(500).json({ error: 'Lỗi server' });
});
app.listen(cfg.port, () => console.log('Server chạy tại cổng', cfg.port));
