-- FLOATING PANEL PRO MAX - Database schema (PostgreSQL 13+)
CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('superadmin','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  device_hash TEXT UNIQUE NOT NULL,
  model TEXT,
  banned BOOLEAN NOT NULL DEFAULT false,
  first_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_ip TEXT
);

CREATE TABLE IF NOT EXISTS license_keys (
  id SERIAL PRIMARY KEY,
  key_hash TEXT UNIQUE NOT NULL,          -- HMAC-SHA256(KEY, KEY_PEPPER); KEY gốc không lưu
  key_hint TEXT NOT NULL,                 -- 4 ký tự cuối để Admin nhận diện
  plan TEXT NOT NULL CHECK (plan IN ('1HOUR','1DAY','7DAY','1MONTH','1YEAR','LIFETIME')),
  duration_seconds BIGINT,                -- NULL = vĩnh viễn
  status TEXT NOT NULL DEFAULT 'unused' CHECK (status IN ('unused','active','banned','revoked')),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by INT REFERENCES admins(id) ON DELETE SET NULL,
  activated_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,                 -- NULL + activated_at != NULL => LIFETIME
  device_id INT REFERENCES devices(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_keys_status ON license_keys(status);
CREATE INDEX IF NOT EXISTS idx_keys_device ON license_keys(device_id);

CREATE TABLE IF NOT EXISTS activations (
  id BIGSERIAL PRIMARY KEY,
  key_id INT REFERENCES license_keys(id) ON DELETE CASCADE,
  device_id INT REFERENCES devices(id) ON DELETE SET NULL,
  event TEXT NOT NULL,                    -- activate | resume | reset | denied
  ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_act_device ON activations(device_id);

CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGSERIAL PRIMARY KEY,
  ip TEXT,
  device_hash TEXT,
  success BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_attempts_time ON login_attempts(created_at);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  admin_id INT,
  admin_name TEXT,
  action TEXT NOT NULL,
  target TEXT,
  detail TEXT,
  ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  name TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ===================== NÂNG CẤP: Admin Hub / Panel động =====================
CREATE TABLE IF NOT EXISTS panel_sections (          -- Danh mục (thanh điều hướng) của Panel
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '📁',
  kind TEXT NOT NULL DEFAULT 'text' CHECK (kind IN ('features','music','contact','text')),
  content TEXT NOT NULL DEFAULT '',
  position TEXT NOT NULL DEFAULT 'top' CHECK (position IN ('top','bottom')),
  enabled BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS panel_features (          -- Chức năng do Admin tự thêm
  id SERIAL PRIMARY KEY,
  section_id INT REFERENCES panel_sections(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '⚡',
  enabled BOOLEAN NOT NULL DEFAULT true,             -- Admin bật/tắt (tắt = khóa hẳn, người dùng không bật được)
  action_type TEXT NOT NULL DEFAULT 'none' CHECK (action_type IN ('none','link','toast','call')),
  action_value TEXT NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS feature_states (          -- Công tắc bật/tắt của từng người dùng (thiết bị)
  device_id INT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  feature_id INT NOT NULL REFERENCES panel_features(id) ON DELETE CASCADE,
  is_on BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (device_id, feature_id)
);
CREATE TABLE IF NOT EXISTS music_tracks (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS share_items (             -- Box Share Key Free ở màn nhập KEY
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  link TEXT NOT NULL DEFAULT '',
  enabled BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3 danh mục mặc định (chỉ tạo khi chưa có danh mục nào)
INSERT INTO panel_sections(name,description,icon,kind,position,sort_order)
SELECT * FROM (VALUES
  ('CHỨC NĂNG','Danh sách chức năng','⚡','features','top',1),
  ('ÂM NHẠC','Trình phát nhạc','🎵','music','top',2),
  ('LIÊN HỆ ADMIN','Hỗ trợ khi gặp lỗi','☎','contact','top',3)
) AS v(name,description,icon,kind,position,sort_order)
WHERE NOT EXISTS (SELECT 1 FROM panel_sections);
