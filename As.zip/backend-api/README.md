# Backend API (Node.js + Express + PostgreSQL)

## Cài đặt (Ubuntu 22.04+, Node ≥ 18)
```bash
sudo apt install -y nodejs npm postgresql nginx
cd backend-api && cp .env.example .env && npm install
sudo -u postgres psql -c "CREATE USER fpm_user WITH PASSWORD 'MAT_KHAU_MANH';"
sudo -u postgres psql -c "CREATE DATABASE fpm OWNER fpm_user;"
```
Sửa `.env`: `DATABASE_URL`, 3 chuỗi bí mật (mỗi chuỗi tạo bằng `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`): `ADMIN_JWT_SECRET`, `SESSION_SECRET`, `KEY_PEPPER`.
> **`KEY_PEPPER` không được đổi/mất** sau khi đã có KEY, nếu không mọi KEY cũ sẽ không khớp.

```bash
npm run migrate                                      # tạo bảng (an toàn khi chạy lại, không xóa dữ liệu)
npm run create-admin -- tenadmin MatKhauDaiHon123 superadmin
npm i -g pm2 && pm2 start src/server.js --name fpm-api
```
HTTPS: dùng `deploy/nginx.conf.example` + `certbot --nginx -d api.your-domain.com`, rồi đặt `TRUST_PROXY=true`, `PUBLIC_URL=https://api.your-domain.com`.

## Biến môi trường chính
| Biến | Ý nghĩa |
|---|---|
| `DATABASE_URL`, `ADMIN_JWT_SECRET`, `SESSION_SECRET`, `KEY_PEPPER` | Bắt buộc (secret ≥ 32 ký tự) |
| `PUBLIC_URL` | URL công khai của API; dùng để tạo link ảnh/nhạc tuyệt đối cho app |
| `ADMIN_ORIGINS` | Origin website Admin được gọi `/api/admin`, vd `https://admin.your-domain.com`. (Tên cũ `CORS_ORIGIN` vẫn dùng được.) |
| `ADMIN_API_ENABLED` | `false` = tắt hẳn API quản trị trên server này |
| `ADMIN_IP_ALLOWLIST` | Chỉ các IP này gọi được `/api/admin` (cần `TRUST_PROXY=true` sau Nginx) |

## API
**Công khai cho app (`/api/v1`)**: `GET /time`, `GET /config`, `POST /keys/activate {key, deviceId, model}`, `POST /keys/status` (Bearer session + `deviceId`).
**Panel (cần session KEY hợp lệ, kiểm tra lại DB mỗi request)**: `GET /api/v1/panel`, `POST /api/v1/panel/features/:id/toggle`, `POST /api/v1/panel/features/:id/run`.
**Quản trị (`/api/admin`, cần JWT admin 8 giờ; `superadmin` cho quản lý admin)**: login, me, stats, keys (tạo/khóa/thu hồi/gia hạn/reset thiết bị/xóa/xuất CSV), devices, config, upload, hub (chức năng, danh mục, nhạc, chia sẻ), logs, admins.

Lỗi: 400/404 sai KEY · 403 khóa/thu hồi/hết hạn/khác thiết bị · 429 nhập sai quá nhiều (8 lần/15 phút theo IP hoặc thiết bị).

## Nâng cấp từ bản cũ (Backend từng phục vụ `/admin/`)
1. Chép đè `src/`, `scripts/`, `package.json`, `.env.example`; **không đụng `.env`, `uploads/`, Database**.
2. Thêm `ADMIN_ORIGINS=https://admin.your-domain.com` vào `.env`.
3. `npm install && npm run migrate && pm2 restart fpm-api`.
4. Triển khai `admin-dashboard` (xem README của nó). Link `/admin/` cũ trên Backend sẽ trả 404.

## Kiểm thử
```bash
npm test                                              # unit test lớp bảo vệ admin (không cần DB)
BASE_URL=https://api.your-domain.com ADMIN_ORIGIN=https://admin.your-domain.com npm run smoke
```
`smoke` kiểm tra: /health, config công khai, `/admin/` = 404, admin API không token bị từ chối, token giả bị từ chối, panel cần session, CORS đúng origin, `/api/v1` không bật CORS. Thêm `TEST_KEY=…` để thử kích hoạt KEY thật và `ADMIN_USER/ADMIN_PASS` để thử đăng nhập admin.
