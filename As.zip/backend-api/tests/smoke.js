// Kiểm tra nhanh Backend ĐANG CHẠY. Dùng: BASE_URL=http://localhost:3000 ADMIN_ORIGIN=https://admin.your-domain.com node tests/smoke.js
// Tùy chọn: TEST_KEY=<KEY thật chưa dùng> để thử kích hoạt; ADMIN_USER/ADMIN_PASS để thử đăng nhập admin.
const BASE = (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, ''); const AO = process.env.ADMIN_ORIGIN || '';
let bad = 0; const ok = (n, c, x = '') => { if (!c) bad++; console.log((c ? 'PASS ' : 'FAIL ') + n + (x ? '  ' + x : '')); };
const j = async (p, o = {}) => { const r = await fetch(BASE + p, o); let b = null; try { b = await r.clone().json(); } catch {} return { r, b }; };
(async () => {
  let x = await j('/health'); ok('GET /health', x.r.status === 200 && x.b.ok);
  x = await j('/api/v1/time'); ok('GET /api/v1/time', x.r.status === 200 && typeof x.b.serverTime === 'number');
  x = await j('/api/v1/config'); ok('GET /api/v1/config (công khai, có appName)', x.r.status === 200 && !!x.b.appName);
  ok('Config công khai không chứa secret', !/secret|pepper|password|hash/i.test(JSON.stringify(x.b)));
  x = await j('/admin/'); ok('Backend KHÔNG phục vụ giao diện Admin', x.r.status === 404);
  x = await j('/'); ok('Trang gốc không chuyển hướng tới /admin', x.r.status !== 302 && x.r.status !== 301);
  x = await j('/api/admin/stats'); ok('Admin API không token → 401/404', [401, 404].includes(x.r.status));
  x = await j('/api/admin/stats', { headers: { Authorization: 'Bearer abc', 'X-Admin': 'true' } }); ok('Token giả + header "admin" từ client bị từ chối', [401, 404].includes(x.r.status));
  x = await j('/api/v1/panel'); ok('Panel API không session → 401', x.r.status === 401);
  x = await j('/api/v1/keys/status', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceId: 'abcdefgh12' }) }); ok('keys/status không session → bị từ chối', [401, 403].includes(x.r.status));
  x = await j('/api/v1/keys/activate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: 'SAI-KEY', deviceId: 'smoke-test-device-1', model: 'smoke' }) }); ok('Kích hoạt KEY sai → 400/404', [400, 404].includes(x.r.status));
  if (AO) {
    x = await j('/api/admin/stats', { method: 'OPTIONS', headers: { Origin: AO, 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'authorization' } }); ok('CORS preflight từ origin Dashboard được chấp nhận', x.r.headers.get('access-control-allow-origin') === AO);
    x = await j('/api/admin/stats', { method: 'OPTIONS', headers: { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'GET' } }); ok('CORS từ origin lạ không được chấp nhận', x.r.headers.get('access-control-allow-origin') !== 'https://evil.example');
  }
  x = await j('/api/v1/config', { headers: { Origin: 'https://evil.example' } }); ok('/api/v1 không bật CORS cho web lạ', !x.r.headers.get('access-control-allow-origin'));
  if (process.env.TEST_KEY) { x = await j('/api/v1/keys/activate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: process.env.TEST_KEY, deviceId: 'smoke-test-device-1', model: 'smoke' }) }); ok('Kích hoạt TEST_KEY', x.r.status === 200 && !!x.b.session);
    if (x.b && x.b.session) { const h = { Authorization: 'Bearer ' + x.b.session, 'X-Device-Id': 'smoke-test-device-1' }; const p = await j('/api/v1/panel', { headers: h }); ok('GET /api/v1/panel với session hợp lệ', p.r.status === 200); } }
  if (process.env.ADMIN_USER) { x = await j('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: process.env.ADMIN_USER, password: process.env.ADMIN_PASS }) }); ok('Đăng nhập admin', x.r.status === 200 && !!x.b.token);
    if (x.b && x.b.token) { const s = await j('/api/admin/stats', { headers: { Authorization: 'Bearer ' + x.b.token } }); ok('GET /api/admin/stats với token admin', s.r.status === 200); } }
  console.log(bad ? `\n${bad} test THẤT BẠI` : '\nTất cả test đạt'); process.exit(bad ? 1 : 0);
})().catch(e => { console.error('Không kết nối được Backend:', e.message); process.exit(2); });
