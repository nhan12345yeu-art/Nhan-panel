// Chạy: node tests/admin-guard.test.js  (không cần Database/thư viện ngoài)
const { createAdminGuard } = require('../src/adminGuard');
const run = (g, ip) => { let r = 'blocked?'; g({ ip }, { status: c => ({ json: () => { r = c; } }) }, () => { r = 'next'; }); return r; };
const cases = [
  [run(createAdminGuard({ enabled: true, allowlist: [] }), '9.9.9.9'), 'next'],
  [run(createAdminGuard({ enabled: false, allowlist: [] }), '1.2.3.4'), 404],
  [run(createAdminGuard({ enabled: true, allowlist: ['1.2.3.4'] }), '::ffff:1.2.3.4'), 'next'],
  [run(createAdminGuard({ enabled: true, allowlist: ['1.2.3.4'] }), '8.8.8.8'), 404]
];
let bad = 0; cases.forEach(([a, b], i) => { const ok = a === b; if (!ok) bad++; console.log(ok ? 'PASS' : 'FAIL', 'case', i + 1); });
process.exit(bad ? 1 : 0);
