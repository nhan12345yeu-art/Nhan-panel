// Dùng: npm run create-admin -- <username> <password> [superadmin|admin]
require('dotenv').config();
const bcrypt = require('bcryptjs'); const { Pool } = require('pg');
(async () => {
  const [u, p, role = 'superadmin'] = process.argv.slice(2);
  if (!u || !p || p.length < 10) { console.error('Cần username và mật khẩu >= 10 ký tự.'); process.exit(1); }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const hash = await bcrypt.hash(p, 12);
  await pool.query(`INSERT INTO admins(username,password_hash,role) VALUES($1,$2,$3)
    ON CONFLICT (username) DO UPDATE SET password_hash=EXCLUDED.password_hash, role=EXCLUDED.role`, [u, hash, role]);
  console.log('Đã tạo/cập nhật admin:', u); await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
